


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;


CREATE TABLE ai_account (
    id character varying NOT NULL,
    name character varying NOT NULL,
    cli character varying NOT NULL,
    folder character varying NOT NULL,
    status character varying NOT NULL,
    status_detail character varying,
    email character varying,
    plan character varying,
    method character varying,
    checked_at character varying,
    signed_out_at character varying,
    signed_out_how character varying,
    created_by character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_account_state (
    key character varying NOT NULL,
    max_parallel integer NOT NULL,
    move_urgent boolean NOT NULL,
    five_hour_used double precision,
    five_hour_resets_at character varying,
    five_hour_status character varying,
    seven_day_used double precision,
    seven_day_resets_at character varying,
    seven_day_status character varying,
    held_until character varying,
    held_reason character varying,
    updated_at character varying
);



CREATE TABLE ai_approval (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    member_id character varying NOT NULL,
    run_id character varying,
    ticket_id character varying,
    action character varying NOT NULL,
    summary character varying NOT NULL,
    payload character varying NOT NULL,
    reason character varying,
    risk character varying NOT NULL,
    status character varying NOT NULL,
    on_behalf_of character varying,
    before character varying NOT NULL,
    requested_at character varying NOT NULL,
    expires_at character varying,
    decided_by character varying,
    decided_at character varying,
    decision_note character varying,
    decided_via character varying
);



CREATE TABLE ai_assist_settings (
    id integer NOT NULL,
    features character varying NOT NULL,
    language character varying NOT NULL,
    tone character varying NOT NULL,
    style_guide character varying NOT NULL,
    monthly_cap double precision,
    per_request_cap double precision,
    over_cap character varying NOT NULL,
    data_scope character varying NOT NULL,
    excluded_docs character varying NOT NULL,
    health character varying NOT NULL,
    paused_until character varying
);



CREATE TABLE ai_audit (
    id character varying NOT NULL,
    seq integer NOT NULL,
    project_id character varying NOT NULL,
    member_id character varying,
    member_name character varying NOT NULL,
    on_behalf_of character varying,
    run_id character varying,
    action character varying NOT NULL,
    target character varying,
    result character varying NOT NULL,
    detail character varying NOT NULL,
    created_at character varying NOT NULL,
    reverted_at character varying,
    reverted_by character varying,
    prev_hash character varying NOT NULL,
    hash character varying NOT NULL
);



CREATE TABLE ai_chat (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    owner character varying NOT NULL,
    title character varying NOT NULL,
    scope character varying NOT NULL,
    ticket_id character varying,
    doc_id character varying,
    scope_id character varying,
    member_id character varying,
    include_docs character varying NOT NULL,
    cost double precision NOT NULL,
    tokens integer NOT NULL,
    applied boolean NOT NULL,
    session_id character varying,
    summary character varying NOT NULL,
    summary_upto character varying,
    compactions integer NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_chat_message (
    id character varying NOT NULL,
    chat_id character varying NOT NULL,
    role character varying NOT NULL,
    text character varying NOT NULL,
    state character varying NOT NULL,
    steps character varying NOT NULL,
    context character varying NOT NULL,
    actions character varying NOT NULL,
    draft_id character varying,
    error character varying NOT NULL,
    retry_at character varying,
    member_id character varying,
    model character varying,
    cost double precision NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    metered boolean NOT NULL,
    feedback character varying NOT NULL,
    created_at character varying NOT NULL,
    finished_at character varying
);



CREATE TABLE ai_config_state (
    member_id character varying NOT NULL,
    version integer NOT NULL,
    synced_at character varying,
    synced_files integer NOT NULL,
    ticks character varying NOT NULL,
    files character varying NOT NULL,
    hooks_ok character varying NOT NULL,
    reset_snapshot character varying,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_decision (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    ticket_id character varying,
    story_id character varying,
    member_id character varying,
    kind character varying NOT NULL,
    title character varying NOT NULL,
    why character varying NOT NULL,
    ref character varying NOT NULL,
    state character varying NOT NULL,
    overridden_by character varying,
    overridden_at character varying,
    override_note character varying,
    at character varying NOT NULL
);



CREATE TABLE ai_digest (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    day character varying NOT NULL,
    summary character varying NOT NULL,
    member_id character varying,
    cost double precision NOT NULL,
    tokens integer NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE ai_draft (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    kind character varying NOT NULL,
    owner character varying NOT NULL,
    member_id character varying,
    member_name character varying NOT NULL,
    ticket_id character varying,
    doc_id character varying,
    chat_message_id character varying,
    insight_id character varying,
    base character varying NOT NULL,
    payload character varying NOT NULL,
    raw character varying NOT NULL,
    status character varying NOT NULL,
    result character varying NOT NULL,
    cost double precision NOT NULL,
    tokens integer NOT NULL,
    created_at character varying NOT NULL,
    expires_at character varying,
    applied_at character varying,
    applied_by character varying
);



CREATE TABLE ai_eval_mark (
    id character varying NOT NULL,
    suite character varying NOT NULL,
    project_id character varying NOT NULL,
    member_id character varying,
    model character varying,
    state character varying NOT NULL,
    score double precision,
    details character varying NOT NULL,
    runs character varying NOT NULL,
    created_at character varying NOT NULL,
    ended_at character varying
);



CREATE TABLE ai_grant (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    kind character varying NOT NULL,
    member_id character varying,
    role character varying,
    ticket_id character varying,
    action character varying,
    amount double precision NOT NULL,
    day character varying,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    revoked_at character varying,
    source_approval_id character varying
);



CREATE TABLE ai_insight (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    kind character varying NOT NULL,
    key character varying NOT NULL,
    ticket_id character varying,
    title character varying NOT NULL,
    detail character varying NOT NULL,
    data character varying NOT NULL,
    score double precision NOT NULL,
    state character varying NOT NULL,
    snoozed_until character varying,
    seen boolean NOT NULL,
    draft_id character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_knowledge_doc (
    id character varying NOT NULL,
    project_id character varying,
    store character varying NOT NULL,
    title character varying NOT NULL,
    kind character varying NOT NULL,
    text character varying NOT NULL,
    summary character varying,
    keywords character varying NOT NULL,
    answers character varying NOT NULL,
    described_by character varying,
    source_name character varying,
    upload_url character varying,
    private boolean NOT NULL,
    tokens integer NOT NULL,
    created_by character varying,
    created_at character varying NOT NULL,
    last_read_at character varying,
    deleted_at character varying
);



CREATE TABLE ai_lesson (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    text character varying NOT NULL,
    state character varying NOT NULL,
    source_ticket_id character varying,
    source_run_id character varying,
    proposed_by character varying,
    kept_by character varying,
    uses integer NOT NULL,
    last_used_at character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_library_item (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    type character varying NOT NULL,
    name character varying NOT NULL,
    description character varying NOT NULL,
    content character varying NOT NULL,
    version integer NOT NULL,
    history character varying NOT NULL,
    created_by character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_member (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    linked_to character varying,
    provider character varying NOT NULL,
    connection character varying NOT NULL,
    description character varying NOT NULL,
    glyph character varying NOT NULL,
    cli_path character varying,
    working_dir character varying,
    base_url character varying,
    model character varying,
    key_enc character varying,
    key_last4 character varying,
    persona character varying NOT NULL,
    resource_access character varying NOT NULL,
    max_parallel integer NOT NULL,
    daily_budget double precision,
    monthly_cap double precision,
    max_runs_per_day integer,
    template character varying NOT NULL,
    ceiling character varying NOT NULL,
    permissions character varying NOT NULL,
    scope character varying NOT NULL,
    config character varying NOT NULL,
    paused boolean NOT NULL,
    paused_at character varying,
    paused_reason character varying,
    health character varying NOT NULL,
    health_detail character varying,
    checked_at character varying,
    cli_version character varying,
    account character varying,
    account_id character varying,
    last_call_at character varying,
    retry_at character varying,
    remove_after_run boolean NOT NULL,
    safe_mode boolean NOT NULL,
    allow_external boolean NOT NULL,
    tokens_per_day integer,
    cap_per_run double precision,
    warn_at character varying NOT NULL,
    key_rotated_at character varying,
    mcp_last_used_at character varying,
    token_revoked_at character varying,
    token_revoked_by character varying,
    created_by character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_memory_note (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    scope character varying NOT NULL,
    scope_key character varying NOT NULL,
    text character varying NOT NULL,
    kind character varying NOT NULL,
    written_by character varying,
    source_run_id character varying,
    source_ticket_id character varying,
    uses integer NOT NULL,
    last_used_at character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_notification (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    event character varying NOT NULL,
    title character varying NOT NULL,
    body character varying NOT NULL,
    ref_kind character varying,
    ref_id character varying,
    member_id character varying,
    people character varying NOT NULL,
    urgent boolean NOT NULL,
    inapp boolean NOT NULL,
    desktop boolean NOT NULL,
    data character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE ai_order_firing (
    id character varying NOT NULL,
    order_id character varying NOT NULL,
    project_id character varying NOT NULL,
    at character varying NOT NULL,
    target character varying,
    ticket_id character varying,
    trigger character varying NOT NULL,
    action character varying NOT NULL,
    would boolean NOT NULL,
    result character varying,
    undo character varying,
    undone_at character varying,
    undone_by character varying
);



CREATE TABLE ai_plugin (
    id character varying NOT NULL,
    project_id character varying,
    name character varying NOT NULL,
    source_kind character varying NOT NULL,
    source character varying NOT NULL,
    ref character varying,
    plugin character varying,
    skills_wanted character varying NOT NULL,
    commit character varying,
    version character varying,
    description character varying,
    path character varying,
    skills character varying NOT NULL,
    hooks integer NOT NULL,
    mcp integer NOT NULL,
    size_bytes integer NOT NULL,
    pinned boolean NOT NULL,
    default_on boolean NOT NULL,
    roles character varying NOT NULL,
    members character varying NOT NULL,
    previous character varying,
    installed_by character varying,
    installed_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_project_knowledge (
    project_id character varying NOT NULL,
    instructions character varying NOT NULL,
    history character varying NOT NULL,
    updated_at character varying,
    updated_by character varying
);



CREATE TABLE ai_project_settings (
    project_id character varying NOT NULL,
    board_ai_id character varying,
    ai_enabled boolean NOT NULL,
    paused_all boolean NOT NULL,
    paused_at character varying,
    paused_by character varying,
    paused_reason character varying,
    safe_mode boolean NOT NULL,
    board_daily_cap double precision,
    board_monthly_budget double precision,
    max_chain_depth integer NOT NULL,
    runs_per_ticket_per_day integer NOT NULL,
    approval_expiry_hours integer NOT NULL,
    board_tokens_per_day integer,
    board_max_parallel integer NOT NULL,
    run_memory_limit_mb integer NOT NULL,
    board_runs_per_day integer,
    board_at_cap character varying NOT NULL,
    approval_on_expiry character varying NOT NULL,
    approvers character varying NOT NULL,
    delegates character varying NOT NULL,
    audit_retention_days integer,
    run_retention_days integer,
    loop_cooldown_s integer NOT NULL,
    no_repeat_chain boolean NOT NULL,
    docs_edits_ask boolean NOT NULL,
    autopilot character varying NOT NULL,
    allowed_domains character varying NOT NULL,
    alert_state character varying NOT NULL,
    checklist character varying NOT NULL,
    key_reminder_days integer NOT NULL,
    auto_trip character varying NOT NULL,
    paused_cancelled integer NOT NULL,
    paused_held integer NOT NULL,
    paused_tokens_revoked boolean NOT NULL,
    paused_let_finish boolean NOT NULL,
    paused_safe_before boolean NOT NULL,
    team_dismissed character varying NOT NULL,
    ops character varying NOT NULL
);



CREATE TABLE ai_repo_scan (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    folder character varying NOT NULL,
    found character varying NOT NULL,
    suggested character varying NOT NULL,
    trial character varying NOT NULL,
    job character varying NOT NULL,
    proposal character varying NOT NULL,
    applied_at character varying,
    created_at character varying NOT NULL
);



CREATE TABLE ai_role_pack (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    key character varying NOT NULL,
    name character varying NOT NULL,
    version integer NOT NULL,
    body character varying NOT NULL,
    history character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL,
    updated_by character varying
);



CREATE TABLE ai_run (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    member_id character varying NOT NULL,
    number integer NOT NULL,
    mode character varying NOT NULL,
    trigger character varying NOT NULL,
    state character varying NOT NULL,
    started_by character varying NOT NULL,
    instruction character varying NOT NULL,
    source_comment_id character varying,
    reply_comment_id character varying,
    include_context boolean NOT NULL,
    chain character varying NOT NULL,
    queued_at character varying NOT NULL,
    started_at character varying,
    ended_at character varying,
    last_output_at character varying,
    ended_reason character varying,
    ended_by character varying,
    exit_code integer,
    summary character varying,
    report character varying NOT NULL,
    question character varying,
    answer character varying,
    session_id character varying,
    steps character varying NOT NULL,
    files character varying NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    tokens_cached integer,
    cost_usd double precision NOT NULL,
    metered boolean NOT NULL,
    context_used integer,
    context_window integer,
    report_back character varying,
    status_before character varying,
    status_changes character varying NOT NULL,
    pid integer,
    token_hash character varying,
    model character varying,
    paused boolean NOT NULL,
    paused_at character varying,
    behind_run_id character varying,
    queue_after_current boolean NOT NULL,
    limit_min integer,
    replaces_comment_id character varying,
    feedback character varying,
    stop_code character varying,
    blocked_move character varying,
    context_notes character varying NOT NULL,
    memory_used character varying,
    started_via character varying,
    peak_rss_mb double precision,
    last_rss_mb double precision,
    restarts character varying NOT NULL,
    diagnosis character varying,
    retry_at character varying,
    retries character varying NOT NULL,
    account_id character varying,
    model_override character varying,
    effort_override character varying,
    details_removed_at character varying
);



CREATE TABLE ai_run_transcript (
    run_id character varying NOT NULL,
    project_id character varying NOT NULL,
    member_id character varying,
    path character varying NOT NULL,
    bytes integer NOT NULL,
    events integer NOT NULL,
    pinned boolean NOT NULL,
    pinned_by character varying,
    started_at character varying NOT NULL,
    ended_at character varying,
    deleted_at character varying
);



CREATE TABLE ai_schedule (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    member_id character varying NOT NULL,
    backup_member_id character varying,
    created_by character varying NOT NULL,
    kind character varying NOT NULL,
    run_at character varying,
    days character varying NOT NULL,
    "time" character varying NOT NULL,
    tz character varying NOT NULL,
    ends character varying NOT NULL,
    ends_after integer,
    ends_on character varying,
    window_end character varying,
    checks character varying NOT NULL,
    review character varying NOT NULL,
    limits character varying NOT NULL,
    catch_up character varying NOT NULL,
    catch_up_hours double precision NOT NULL,
    notify character varying NOT NULL,
    notify_people character varying NOT NULL,
    instruction character varying NOT NULL,
    state character varying NOT NULL,
    paused_reason character varying,
    failures_in_row integer NOT NULL,
    runs_count integer NOT NULL,
    next_run_at character varying,
    ticket_seen_at character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_schedule_run (
    id character varying NOT NULL,
    schedule_id character varying NOT NULL,
    project_id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    slot_at character varying NOT NULL,
    state character varying NOT NULL,
    catch_up boolean NOT NULL,
    member_id character varying,
    run_ids character varying NOT NULL,
    attempts integer NOT NULL,
    fix_round integer NOT NULL,
    results character varying NOT NULL,
    review character varying NOT NULL,
    note character varying,
    started_at character varying,
    ended_at character varying,
    duration_s integer NOT NULL,
    cost_usd double precision NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_skill_use (
    id integer NOT NULL,
    run_id character varying NOT NULL,
    project_id character varying NOT NULL,
    member_id character varying,
    kind character varying NOT NULL,
    name character varying NOT NULL,
    plugin character varying,
    at character varying NOT NULL
);



CREATE SEQUENCE ai_skill_use_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



ALTER SEQUENCE ai_skill_use_id_seq OWNED BY ai_skill_use.id;



CREATE TABLE ai_standing_order (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    name character varying NOT NULL,
    sentence character varying NOT NULL,
    rule character varying NOT NULL,
    state character varying NOT NULL,
    trial_days integer NOT NULL,
    trial_started_at character varying,
    trial_fired_at character varying,
    fired integer NOT NULL,
    would_have integer NOT NULL,
    last_fired_at character varying,
    last_summary character varying,
    template character varying,
    created_by character varying,
    created_at character varying NOT NULL
);



CREATE TABLE ai_ticket_flag (
    id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    kind character varying NOT NULL,
    data character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL,
    resolved_at character varying,
    resolved_by character varying,
    resolution character varying
);



CREATE TABLE ai_ticket_pace (
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    pace character varying NOT NULL,
    set_by character varying,
    set_at character varying NOT NULL
);



CREATE TABLE ai_ticket_step (
    id character varying NOT NULL,
    ticket_id character varying NOT NULL,
    seq integer NOT NULL,
    idx integer NOT NULL,
    key character varying NOT NULL,
    label character varying NOT NULL,
    kind character varying NOT NULL,
    role character varying,
    state character varying NOT NULL,
    attempt integer NOT NULL,
    member_id character varying,
    run_id character varying,
    note_in character varying,
    note character varying,
    outcome character varying,
    result character varying,
    started_at character varying,
    ended_at character varying
);



CREATE TABLE ai_ticket_workflow (
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    template_key character varying NOT NULL,
    template_name character varying NOT NULL,
    template_version integer NOT NULL,
    steps character varying NOT NULL,
    state character varying NOT NULL,
    stop_reason character varying,
    stop_detail character varying,
    review_depth character varying,
    depth_by character varying,
    depth_note character varying,
    pace character varying,
    rounds character varying NOT NULL,
    objections character varying NOT NULL,
    rulings character varying NOT NULL,
    arbitration_run_id character varying,
    reviewer_id character varying,
    seq_base integer NOT NULL,
    attached_by character varying,
    meta character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE ai_usage (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    feature character varying NOT NULL,
    member_id character varying,
    person character varying,
    cost double precision NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    metered boolean NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE ai_watched_pr (
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    number integer NOT NULL,
    url character varying,
    branch character varying NOT NULL,
    repo character varying NOT NULL,
    state character varying NOT NULL,
    ci character varying,
    red character varying,
    seen_comments character varying NOT NULL,
    pending_comments character varying NOT NULL,
    checked_at character varying,
    last_error character varying
);



CREATE TABLE ai_workflow_template (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    key character varying NOT NULL,
    name character varying NOT NULL,
    version integer NOT NULL,
    body character varying NOT NULL,
    history character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL,
    updated_by character varying
);



CREATE TABLE ai_workspace_defaults (
    id integer NOT NULL,
    template character varying NOT NULL,
    ceiling character varying NOT NULL,
    delete_mode character varying NOT NULL,
    daily_budget double precision,
    monthly_cap double precision,
    updated_by character varying,
    updated_at character varying
);



CREATE TABLE ai_worktree (
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    repo character varying NOT NULL,
    path character varying NOT NULL,
    branch character varying NOT NULL,
    base character varying NOT NULL,
    port integer,
    state character varying NOT NULL,
    handover character varying,
    pr_url character varying,
    pr_number integer,
    conflict_files character varying NOT NULL,
    prepared_at character varying,
    prepare_s integer,
    created_at character varying NOT NULL,
    last_used_at character varying,
    merged_at character varying
);



CREATE TABLE alembic_version (
    version_num character varying(32) NOT NULL
);



CREATE TABLE canvas (
    id character varying NOT NULL,
    project_id character varying,
    owner_kind character varying NOT NULL,
    owner_id character varying NOT NULL,
    page_id character varying,
    title character varying NOT NULL,
    rev integer NOT NULL,
    version integer NOT NULL,
    board_count integer NOT NULL,
    total_bytes integer NOT NULL,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_by character varying NOT NULL,
    updated_at character varying NOT NULL,
    deleted_at character varying,
    deleted_by character varying
);



CREATE TABLE canvas_comment (
    id character varying NOT NULL,
    thread_id character varying NOT NULL,
    author character varying NOT NULL,
    body character varying NOT NULL,
    mentions character varying NOT NULL,
    ai character varying,
    created_at character varying NOT NULL,
    edited_at character varying
);



CREATE TABLE canvas_proposal (
    id character varying NOT NULL,
    canvas_id character varying NOT NULL,
    author character varying NOT NULL,
    member_id character varying,
    job_id character varying,
    request character varying NOT NULL,
    note character varying NOT NULL,
    status character varying NOT NULL,
    changes character varying NOT NULL,
    version integer,
    created_at character varying NOT NULL,
    decided_by character varying,
    decided_at character varying
);



CREATE TABLE canvas_thread (
    id character varying NOT NULL,
    canvas_id character varying NOT NULL,
    number integer NOT NULL,
    board_id character varying,
    x double precision NOT NULL,
    y double precision NOT NULL,
    page character varying,
    anchor character varying,
    status character varying NOT NULL,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    resolved_by character varying,
    resolved_at character varying
);



CREATE TABLE canvas_version (
    id character varying NOT NULL,
    canvas_id character varying NOT NULL,
    version integer NOT NULL,
    name character varying,
    reason character varying NOT NULL,
    author character varying NOT NULL,
    note character varying,
    changes character varying NOT NULL,
    summary character varying NOT NULL,
    doc character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE diagram (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    label character varying NOT NULL,
    summary character varying NOT NULL,
    item_kind character varying,
    item_id character varying,
    version integer NOT NULL,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_by character varying NOT NULL,
    updated_at character varying NOT NULL,
    deleted_at character varying,
    deleted_by character varying
);



CREATE TABLE diagram_settings (
    id integer NOT NULL,
    mode character varying NOT NULL,
    url character varying NOT NULL
);



CREATE TABLE diagram_version (
    id character varying NOT NULL,
    diagram_id character varying NOT NULL,
    version integer NOT NULL,
    source character varying NOT NULL,
    svg character varying NOT NULL,
    preview_kind character varying NOT NULL,
    author character varying NOT NULL,
    note character varying,
    created_at character varying NOT NULL
);



CREATE TABLE docs_ai_check (
    page_id character varying NOT NULL,
    project_id character varying NOT NULL,
    state character varying NOT NULL,
    reasons character varying NOT NULL,
    based_on_version integer NOT NULL,
    deps_hash character varying NOT NULL,
    checked_at character varying NOT NULL,
    ok_until character varying,
    ok_hash character varying,
    dismissed character varying NOT NULL,
    job_id character varying
);



CREATE TABLE docs_ai_health (
    project_id character varying NOT NULL,
    data character varying NOT NULL,
    checked_at character varying,
    digest_at character varying
);



CREATE TABLE docs_ai_ignore (
    page_id character varying NOT NULL,
    key character varying NOT NULL,
    by character varying NOT NULL,
    at character varying NOT NULL
);



CREATE TABLE docs_ai_job (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    page_id character varying,
    thread_id character varying,
    comment_id character varying,
    member_id character varying,
    kind character varying NOT NULL,
    state character varying NOT NULL,
    started_by character varying NOT NULL,
    instruction character varying NOT NULL,
    session_id character varying,
    reads character varying NOT NULL,
    steps character varying NOT NULL,
    result character varying NOT NULL,
    error character varying NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    cost_usd double precision NOT NULL,
    metered boolean NOT NULL,
    reply_comment_id character varying,
    queued_at character varying NOT NULL,
    started_at character varying,
    ended_at character varying
);



CREATE TABLE docs_ai_proposal (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    page_id character varying NOT NULL,
    member_id character varying NOT NULL,
    run_id character varying,
    job_id character varying,
    ticket_id character varying,
    approval_id character varying,
    on_behalf_of character varying,
    base_version integer NOT NULL,
    status character varying NOT NULL,
    summary character varying NOT NULL,
    changes character varying NOT NULL,
    created_at character varying NOT NULL,
    expires_at character varying,
    decided_by character varying,
    decided_at character varying,
    decision_note character varying
);



CREATE TABLE docs_ai_session (
    scope character varying NOT NULL,
    member_id character varying NOT NULL,
    project_id character varying NOT NULL,
    session_id character varying NOT NULL,
    calls integer NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE docs_ai_settings (
    project_id character varying NOT NULL,
    enabled boolean NOT NULL,
    member_id character varying,
    read_scope character varying NOT NULL,
    picked_pages character varying NOT NULL,
    style_page_id character varying,
    edits_mode character varying NOT NULL,
    proposal_days integer NOT NULL,
    freshness_on boolean NOT NULL,
    guidance_limit integer NOT NULL,
    digest_on boolean NOT NULL,
    updated_by character varying,
    updated_at character varying NOT NULL
);



CREATE TABLE docs_anchor_aliases (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    old_slug character varying NOT NULL,
    new_slug character varying NOT NULL
);



CREATE TABLE docs_comment (
    id character varying NOT NULL,
    thread_id character varying NOT NULL,
    author character varying NOT NULL,
    body character varying NOT NULL,
    mentions character varying NOT NULL,
    created_at character varying NOT NULL,
    edited_at character varying,
    ai character varying
);



CREATE TABLE docs_comment_event (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    page_id character varying,
    thread_id character varying,
    comment_id character varying,
    kind character varying NOT NULL,
    actor character varying NOT NULL,
    mentioned character varying NOT NULL,
    recipients character varying NOT NULL,
    page_title character varying NOT NULL,
    snippet character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE docs_comment_read (
    id character varying NOT NULL,
    thread_id character varying NOT NULL,
    reader character varying NOT NULL,
    read_at character varying NOT NULL
);



CREATE TABLE docs_comment_thread (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    kind character varying NOT NULL,
    status character varying NOT NULL,
    anchor_quote character varying,
    anchor_prefix character varying NOT NULL,
    anchor_suffix character varying NOT NULL,
    anchor_section character varying,
    anchor_state character varying NOT NULL,
    anchor_pos integer,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    resolved_by character varying,
    resolved_at character varying
);



CREATE TABLE docs_draft (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    author character varying NOT NULL,
    title character varying NOT NULL,
    markdown character varying NOT NULL,
    base_version integer NOT NULL,
    saves integer NOT NULL,
    updated_at character varying NOT NULL,
    ai_source character varying
);



CREATE TABLE docs_link (
    id character varying NOT NULL,
    source_page_id character varying NOT NULL,
    source_section character varying,
    target_page_id character varying,
    target_title character varying,
    target_anchor character varying,
    target_ticket_id character varying,
    display_text character varying,
    snippet character varying NOT NULL,
    origin character varying NOT NULL
);



CREATE TABLE docs_page (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    parent_id character varying,
    "position" integer NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    status character varying NOT NULL,
    version integer NOT NULL,
    created_by character varying NOT NULL,
    updated_by character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL,
    deleted_at character varying,
    deleted_by character varying,
    deleted_root_id character varying,
    ai_hidden boolean NOT NULL,
    ai_guidance boolean NOT NULL,
    kind character varying NOT NULL
);



CREATE TABLE docs_page_seen (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    viewer character varying NOT NULL,
    version integer NOT NULL,
    seen_at character varying NOT NULL
);



CREATE TABLE docs_title_aliases (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    old_title character varying NOT NULL
);



CREATE TABLE docs_version (
    id character varying NOT NULL,
    page_id character varying NOT NULL,
    version integer NOT NULL,
    title character varying NOT NULL,
    markdown character varying NOT NULL,
    author character varying NOT NULL,
    note character varying,
    created_at character varying NOT NULL,
    diagram_versions character varying NOT NULL,
    with_ai boolean NOT NULL
);



CREATE TABLE idea_advice (
    id character varying NOT NULL,
    idea_id character varying NOT NULL,
    action character varying NOT NULL,
    reason character varying NOT NULL,
    confidence character varying NOT NULL,
    target_id character varying,
    archive_reason character varying,
    park_days integer,
    idea_stamp character varying NOT NULL,
    member_id character varying,
    cost double precision NOT NULL,
    state character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE idea_ai_settings (
    project_id character varying NOT NULL,
    enabled boolean NOT NULL,
    triage_advice boolean NOT NULL,
    weekly_grooming boolean NOT NULL,
    ask boolean NOT NULL,
    read_docs boolean NOT NULL,
    read_repo boolean NOT NULL,
    daily_cap double precision NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE idea_assumption (
    id character varying NOT NULL,
    idea_id character varying NOT NULL,
    "position" integer NOT NULL,
    text character varying NOT NULL,
    impact character varying NOT NULL,
    status character varying NOT NULL,
    test_ticket_id character varying,
    ai boolean NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE idea_comment (
    id character varying NOT NULL,
    idea_id character varying NOT NULL,
    author character varying,
    body character varying NOT NULL,
    ai boolean NOT NULL,
    run_id character varying,
    created_at character varying NOT NULL,
    edited_at character varying
);



CREATE TABLE idea_counter (
    id integer NOT NULL,
    counter integer NOT NULL
);



CREATE TABLE idea_digest (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    text character varying NOT NULL,
    items character varying NOT NULL,
    ai boolean NOT NULL,
    member_id character varying,
    cost double precision NOT NULL,
    ideas_read integer NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE idea_evidence (
    id character varying NOT NULL,
    assumption_id character varying NOT NULL,
    kind character varying NOT NULL,
    title character varying NOT NULL,
    ref character varying NOT NULL,
    created_by character varying,
    created_at character varying NOT NULL
);



CREATE TABLE idea_log_entry (
    id character varying NOT NULL,
    idea_id character varying NOT NULL,
    kind character varying NOT NULL,
    body character varying NOT NULL,
    author character varying,
    ai boolean NOT NULL,
    pinned boolean NOT NULL,
    assumption_id character varying,
    attachments character varying NOT NULL,
    ticket_id character varying,
    created_at character varying NOT NULL
);



CREATE TABLE idea_ticket (
    id character varying NOT NULL,
    project_id character varying,
    title character varying NOT NULL,
    description character varying NOT NULL,
    idea_status character varying NOT NULL,
    stage character varying NOT NULL,
    park_until character varying,
    archive_reason character varying,
    source character varying NOT NULL,
    source_ref character varying NOT NULL,
    created_by character varying,
    owner character varying,
    park_note character varying,
    archive_note character varying,
    stage_changed_at character varying,
    prev_state character varying NOT NULL,
    merged_into_id character varying,
    merged_at character varying,
    merge_undo character varying NOT NULL,
    shipped_at character varying,
    outcome character varying,
    outcome_note character varying,
    former_ticket_id character varying,
    effort_guess character varying,
    workspace_retention character varying NOT NULL,
    body character varying NOT NULL,
    details character varying NOT NULL,
    idea_color character varying NOT NULL,
    idea_emoji character varying NOT NULL,
    idea_energy character varying,
    tags character varying NOT NULL,
    problem_statement character varying,
    ice_impact integer NOT NULL,
    ice_effort integer NOT NULL,
    ice_confidence integer NOT NULL,
    revisit_date character varying,
    last_touched_at character varying,
    promoted_to_ticket_id character varying,
    promoted_at character varying,
    activity_trail character varying NOT NULL,
    microthoughts character varying NOT NULL,
    assumptions character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE idea_vote (
    id character varying NOT NULL,
    idea_id character varying NOT NULL,
    voter character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE kanban_change (
    id bigint NOT NULL,
    origin character varying(32) NOT NULL,
    at double precision NOT NULL
);



CREATE SEQUENCE kanban_change_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



ALTER SEQUENCE kanban_change_id_seq OWNED BY kanban_change.id;



CREATE TABLE member (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    name character varying NOT NULL,
    color character varying NOT NULL,
    role character varying NOT NULL,
    kind character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE notification (
    id character varying NOT NULL,
    recipient character varying NOT NULL,
    event_id integer NOT NULL,
    last_event_id integer NOT NULL,
    project_id character varying,
    kind character varying NOT NULL,
    needs boolean NOT NULL,
    group_key character varying NOT NULL,
    count integer NOT NULL,
    items character varying NOT NULL,
    target_kind character varying,
    target_id character varying,
    ticket_id character varying,
    page_id character varying,
    member_id character varying,
    actor character varying,
    title character varying NOT NULL,
    body character varying NOT NULL,
    data character varying NOT NULL,
    inapp boolean NOT NULL,
    desktop boolean NOT NULL,
    read_at character varying,
    done_at character varying,
    done_reason character varying,
    done_by character varying,
    snoozed_until character varying,
    cleared_at character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE notify_event (
    id integer NOT NULL,
    project_id character varying,
    kind character varying NOT NULL,
    op character varying NOT NULL,
    needs boolean NOT NULL,
    target_kind character varying,
    target_id character varying,
    ticket_id character varying,
    page_id character varying,
    member_id character varying,
    actor character varying,
    title character varying NOT NULL,
    body character varying NOT NULL,
    data character varying NOT NULL,
    recipients character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE SEQUENCE notify_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



ALTER SEQUENCE notify_event_id_seq OWNED BY notify_event.id;



CREATE TABLE notify_follow (
    id character varying NOT NULL,
    recipient character varying NOT NULL,
    scope character varying NOT NULL,
    scope_id character varying NOT NULL,
    project_id character varying,
    level character varying NOT NULL,
    until character varying,
    label character varying NOT NULL,
    created_at character varying NOT NULL
);



CREATE TABLE notify_prefs (
    recipient character varying NOT NULL,
    prefs character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE project (
    id character varying NOT NULL,
    name character varying NOT NULL,
    prefix character varying NOT NULL,
    color character varying NOT NULL,
    ticket_counter integer NOT NULL,
    repo_path character varying,
    worktree_template character varying,
    worktree_by_default boolean NOT NULL,
    docs_enabled boolean NOT NULL,
    docs_edit_policy character varying NOT NULL
);



CREATE TABLE sketch (
    id character varying NOT NULL,
    project_id character varying,
    owner_kind character varying NOT NULL,
    owner_id character varying NOT NULL,
    title character varying NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    layer_count integer NOT NULL,
    version integer NOT NULL,
    png_bytes integer NOT NULL,
    source_bytes integer NOT NULL,
    created_by character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_by character varying NOT NULL,
    updated_at character varying NOT NULL,
    deleted_at character varying,
    deleted_by character varying
);



CREATE TABLE story (
    ticket_id character varying NOT NULL,
    project_id character varying NOT NULL,
    state character varying NOT NULL,
    approve character varying NOT NULL,
    budget_tokens integer NOT NULL,
    pm_id character varying,
    plan character varying NOT NULL,
    paused boolean NOT NULL,
    review_note character varying,
    history character varying NOT NULL,
    meta character varying NOT NULL,
    created_by character varying,
    created_at character varying NOT NULL,
    handed_at character varying,
    started_at character varying,
    closed_at character varying
);



CREATE TABLE ticket (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    type character varying NOT NULL,
    status character varying NOT NULL,
    priority character varying NOT NULL,
    estimate double precision,
    due_date character varying,
    tags character varying NOT NULL,
    parent_id character varying,
    comments character varying NOT NULL,
    acceptance_criteria character varying NOT NULL,
    sub_tasks character varying NOT NULL,
    activity_log character varying NOT NULL,
    work_log character varying NOT NULL,
    test_cases character varying NOT NULL,
    start_date character varying,
    wont_do_reason character varying,
    created_by character varying,
    assignee character varying,
    blocks character varying NOT NULL,
    blocked_by character varying NOT NULL,
    block_done_if_acs_incomplete boolean NOT NULL,
    block_done_if_tcs_incomplete boolean NOT NULL,
    links character varying NOT NULL,
    branches character varying NOT NULL,
    workspace_retention_days integer,
    repo_path character varying,
    reopen_count integer NOT NULL,
    last_reopened_at character varying,
    last_reopened_by character varying,
    last_reopen_reason character varying,
    reopen_history character varying NOT NULL,
    pending boolean NOT NULL,
    pending_reason_type character varying,
    pending_ticket_id character varying,
    pending_member_id character varying,
    pending_party character varying,
    pending_note character varying,
    pending_since character varying,
    pending_by character varying,
    from_idea_id character varying,
    tests_assumption_id character varying,
    wave_pin integer,
    review_requested_from character varying,
    created_at character varying NOT NULL,
    updated_at character varying NOT NULL
);



CREATE TABLE workspace_settings (
    id integer NOT NULL,
    enabled boolean NOT NULL,
    root_path character varying NOT NULL,
    default_retention_days integer
);



ALTER TABLE ONLY ai_skill_use ALTER COLUMN id SET DEFAULT nextval('ai_skill_use_id_seq'::regclass);



ALTER TABLE ONLY kanban_change ALTER COLUMN id SET DEFAULT nextval('kanban_change_id_seq'::regclass);



ALTER TABLE ONLY notify_event ALTER COLUMN id SET DEFAULT nextval('notify_event_id_seq'::regclass);



INSERT INTO ai_account VALUES
	('ai_account-0', 'name 0', 'cli 0', 'folder 0', 'status 0', 'status_detail 0', 'email 0', 'plan 0', 'method 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'signed_out_how 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_account-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_account-2', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_account_state VALUES
	('ai_account_state-0', 0, false, 0.25, '2025-03-01T10:00:00.000000+00:00', 'five_hour_status 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'seven_day_status 0', 'held_until 0', 'held_reason 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_account_state-1', 7, true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('ai_account_state-2', 14, false, 3.25, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 3.25, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_approval VALUES
	('ai_approval-0', 'p-1', 'member-0', 'run-0', 'ticket-0', 'action 0', 'summary 0', 'payload 0', 'reason 0', 'risk 0', 'status 0', 'on_behalf_of 0', 'before 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'decided_by 0', '2025-03-01T10:00:00.000000+00:00', 'decision_note 0', 'decided_via 0'),
	('ai_approval-1', 'p-2', 'member-1', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL, NULL, NULL),
	('ai_approval-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_assist_settings VALUES
	(1, 'features 0', 'language 0', 'tone 0', 'style_guide 0', 0.25, 0.25, 'over_cap 0', 'data_scope 0', 'excluded_docs 0', 'health 0', 'paused_until 0'),
	(2, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL),
	(3, '', '', '', '', 3.25, 3.25, '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_audit VALUES
	('ai_audit-0', 0, 'p-1', 'member-0', 'member_name 0', 'on_behalf_of 0', 'run-0', 'action 0', 'target 0', 'result 0', 'detail 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'reverted_by 0', 'prev_hash 0', 'hash 0'),
	('ai_audit-1', 7, 'p-2', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('ai_audit-2', 14, 'p-missing', 'missing-parent', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '');



INSERT INTO ai_chat VALUES
	('ai_chat-0', 'p-1', 'owner 0', 'title 0', 'scope 0', 'ticket-0', 'doc-0', 'scope-0', 'member-0', 'include_docs 0', 0.25, 0, false, 'session-0', 'summary 0', 'summary_upto 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_chat-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 1.75, 7, true, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 7, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_chat-2', 'p-missing', '', '', '', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', '', 3.25, 14, false, 'missing-parent', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00'),
	('c-ticket', 'p-1', 'owner 0', 'title 0', 'ticket', 't-open', NULL, 'scope-0', 'member-0', 'include_docs 0', 0.25, 0, false, 'session-0', 'summary 0', 'summary_upto 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('c-doc', 'p-1', 'owner 0', 'title 0', 'doc', NULL, 'pg-published', 'scope-0', 'member-0', 'include_docs 0', 0.25, 0, false, 'session-0', 'summary 0', 'summary_upto 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('c-project', 'p-1', 'owner 0', 'title 0', 'project', 't-done', 'pg-draft', 'scope-0', 'member-0', 'include_docs 0', 0.25, 0, false, 'session-0', 'summary 0', 'summary_upto 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO ai_chat_message VALUES
	('ai_chat_message-0', 'chat-0', 'role 0', 'text 0', 'state 0', 'steps 0', 'context 0', 'actions 0', 'draft-0', 'error 0', '2025-03-01T10:00:00.000000+00:00', 'member-0', 'model 0', 0.25, 0, 0, false, 'feedback 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_chat_message-1', 'chat-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 1.75, 7, 7, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL),
	('ai_chat_message-2', 'missing-parent', '', '', '', '', '', '', 'missing-parent', '', '2025-05-05T05:05:05.555555+00:00', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 3.25, 14, 14, false, '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_config_state VALUES
	('ai_config_state-0', 0, '2025-03-01T10:00:00.000000+00:00', 0, 'ticks 0', 'files 0', 'hooks_ok 0', 'reset_snapshot 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_config_state-1', 7, NULL, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('ai_config_state-2', 14, '2025-05-05T05:05:05.555555+00:00', 14, '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_decision VALUES
	('ai_decision-0', 'p-1', 'ticket-0', 'story-0', 'member-0', 'kind 0', 'title 0', 'why 0', 'ref 0', 'state 0', 'overridden_by 0', '2025-03-01T10:00:00.000000+00:00', 'override_note 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_decision-1', 'p-2', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00'),
	('ai_decision-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_digest VALUES
	('ai_digest-0', 'p-1', '2025-03-01T10:00:00.000000+00:00', 'summary 0', 'member-0', 0.25, 0, '2025-03-01T10:00:00.000000+00:00'),
	('ai_digest-1', 'p-2', '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 1.75, 7, '2025-04-01T00:00:00.000000+00:00'),
	('ai_digest-2', 'p-missing', '2025-05-05T05:05:05.555555+00:00', '', 'missing-parent', 3.25, 14, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_draft VALUES
	('ai_draft-0', 'p-1', 'kind 0', 'owner 0', 'member-0', 'member_name 0', 'ticket-0', 'doc-0', 'chat_message-0', 'insight-0', 'base 0', 'payload 0', 'raw 0', 'status 0', 'result 0', 0.25, 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'applied_by 0'),
	('ai_draft-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 1.75, 7, '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL),
	('ai_draft-2', 'p-missing', '', '', 'missing-parent', '', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '', '', '', 3.25, 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_eval_mark VALUES
	('ai_eval_mark-0', 'suite 0', 'p-1', 'member-0', 'model 0', 'state 0', 0.25, 'details 0', 'runs 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_eval_mark-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'p-2', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL),
	('ai_eval_mark-2', '', 'p-missing', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 3.25, '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_grant VALUES
	('ai_grant-0', 'p-1', 'kind 0', 'member-0', 'role 0', 'ticket-0', 'action 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'source_approval-0'),
	('ai_grant-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 1.75, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('ai_grant-2', 'p-missing', '', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 3.25, '2025-05-05T05:05:05.555555+00:00', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'missing-parent');



INSERT INTO ai_insight VALUES
	('ai_insight-0', 'p-1', 'kind 0', 'key 0', 'ticket-0', 'title 0', 'detail 0', 'data 0', 0.25, 'state 0', 'snoozed_until 0', false, 'draft-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_insight-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 1.75, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, true, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_insight-2', 'p-missing', '', '', 'missing-parent', '', '', '', 3.25, '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_knowledge_doc VALUES
	('ai_knowledge_doc-0', 'p-1', 'store 0', 'title 0', 'kind 0', 'text 0', 'summary 0', 'keywords 0', 'answers 0', 'described_by 0', 'source_name 0', 'upload_url 0', false, 0, 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_knowledge_doc-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, true, 7, NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('ai_knowledge_doc-2', 'p-missing', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_lesson VALUES
	('ai_lesson-0', 'p-1', 'text 0', 'state 0', 'source_ticket-0', 'source_run-0', 'proposed_by 0', 'kept_by 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_lesson-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 7, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_lesson-2', 'p-missing', '', '', 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_library_item VALUES
	('ai_library_item-0', 'p-1', 'type 0', 'name 0', 'description 0', 'content 0', 0, 'history 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_library_item-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_library_item-2', 'p-missing', '', '', '', '', 14, '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_member VALUES
	('ai_member-0', 'p-1', 'linked_to 0', 'provider 0', 'connection 0', 'description 0', 'glyph 0', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_member-1', 'p-2', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_member-2', 'p-missing', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 14, 3.25, 3.25, 14, '', '', '', '', '', false, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', false, false, false, 14, 3.25, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00'),
	('m-claude-code', 'p-2', 'linked_to 0', 'claude-code', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-antigravity', 'p-2', 'linked_to 0', 'antigravity', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-openai', 'p-2', 'linked_to 0', 'openai', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-gemini', 'p-2', 'linked_to 0', 'gemini', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-custom', 'p-2', 'linked_to 0', 'custom', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-mcp-client', 'p-2', 'linked_to 0', 'mcp-client', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-unknown', 'p-2', 'linked_to 0', 'unknown', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-anthropic', 'p-2', 'linked_to 0', 'anthropic', 'connection 0', 'description 0', 'hex', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-human-with-profile', 'p-2', 'linked_to 0', 'openai', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('m-no-member-row', 'p-2', 'linked_to 0', 'gemini', 'connection 0', 'description 0', 'spark', 'cli_path 0', 'working_dir 0', 'base_url 0', 'model 0', 'key_enc 0', 'key_last4 0', 'persona 0', 'resource_access 0', 0, 0.25, 0.25, 0, 'template 0', 'ceiling 0', 'permissions 0', 'scope 0', 'config 0', false, '2025-03-01T10:00:00.000000+00:00', 'paused_reason 0', 'health 0', 'health_detail 0', '2025-03-01T10:00:00.000000+00:00', 'cli_version 0', 'account 0', 'account-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', false, false, false, 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'token_revoked_by 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO ai_memory_note VALUES
	('ai_memory_note-0', 'p-1', 'scope 0', 'scope_key 0', 'text 0', 'kind 0', 'written_by 0', 'source_run-0', 'source_ticket-0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_memory_note-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 7, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_memory_note-2', 'p-missing', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_notification VALUES
	('ai_notification-0', 'p-1', 'event 0', 'title 0', 'body 0', 'ref_kind 0', 'ref-0', 'member-0', 'people 0', false, false, false, 'data 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_notification-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('ai_notification-2', 'p-missing', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', '', false, false, false, '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_order_firing VALUES
	('ai_order_firing-0', 'order-0', 'p-1', '2025-03-01T10:00:00.000000+00:00', 'target 0', 'ticket-0', 'trigger 0', 'action 0', false, 'result 0', 'undo 0', '2025-03-01T10:00:00.000000+00:00', 'undone_by 0'),
	('ai_order_firing-1', 'order-1', 'p-2', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, NULL, NULL, NULL),
	('ai_order_firing-2', 'missing-parent', 'p-missing', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', '', '', false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_plugin VALUES
	('ai_plugin-0', 'p-1', 'name 0', 'source_kind 0', 'source 0', 'ref 0', 'plugin 0', 'skills_wanted 0', 'commit 0', 'version 0', 'description 0', 'path 0', 'skills 0', 0, 0, 0, false, false, 'roles 0', 'members 0', 'previous 0', 'installed_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_plugin-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 7, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_plugin-2', 'p-missing', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 14, 14, 14, false, false, '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_project_knowledge VALUES
	('ai_project_knowledge-0', 'instructions 0', 'history 0', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0'),
	('ai_project_knowledge-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL),
	('ai_project_knowledge-2', '', '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_project_settings VALUES
	('ai_project_settings-0', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 0, 0, 0, 0, 0, 0, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('ai_project_settings-1', NULL, true, true, NULL, NULL, NULL, true, NULL, NULL, 7, 7, 7, NULL, 7, 7, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 7, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, true, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('ai_project_settings-2', 'missing-parent', false, false, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, 3.25, 3.25, 14, 14, 14, 14, 14, 14, 14, '', '', '', '', 14, 14, 14, false, false, '', '', '', '', 14, '', 14, 14, false, false, false, '', ''),
	('p-1', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 6, 0, 0, 0, 0, 60, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-2', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 9, 0, 0, 0, 0, NULL, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-bad-json', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 6, 0, 0, 0, 0, 100, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-empty', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 15, 0, 0, 0, 0, 60, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-null', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 0, 0, 0, 0, 0, 0, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-list', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 0, 0, 0, 0, 0, 0, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0'),
	('p-last', 'board_ai-0', false, false, '2025-03-01T10:00:00.000000+00:00', 'paused_by 0', 'paused_reason 0', false, 0.25, 0.25, 0, 0, 0, 0, 0, 0, 0, 'board_at_cap 0', 'approval_on_expiry 0', 'approvers 0', 'delegates 0', 0, 0, 0, false, false, 'autopilot 0', 'allowed_domains 0', 'alert_state 0', 'checklist 0', 0, 'auto_trip 0', 0, 0, false, false, false, 'team_dismissed 0', 'ops 0');



INSERT INTO ai_repo_scan VALUES
	('ai_repo_scan-0', 'p-1', 'folder 0', 'found 0', 'suggested 0', 'trial 0', 'job 0', 'proposal 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_repo_scan-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('ai_repo_scan-2', 'p-missing', '', '', '', '', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_role_pack VALUES
	('ai_role_pack-0', 'p-1', 'key 0', 'name 0', 0, 'body 0', 'history 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0'),
	('ai_role_pack-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00', NULL),
	('ai_role_pack-2', 'p-missing', '', '', 14, '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_run VALUES
	('ai_run-0', 'p-1', 'ticket-0', 'member-0', 0, 'mode 0', 'trigger 0', 'state 0', 'started_by 0', 'instruction 0', 'source_comment-0', 'reply_comment-0', false, 'chain 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'ended_reason 0', 'ended_by 0', 0, 'summary 0', 'report 0', 'question 0', 'answer 0', 'session-0', 'steps 0', 'files 0', 0, 0, 0, 0.25, false, 0, 0, 'report_back 0', 'status_before 0', 'status_changes 0', 0, 'token_hash 0', 'model 0', false, '2025-03-01T10:00:00.000000+00:00', 'behind_run-0', false, 0, 'replaces_comment-0', 'feedback 0', 'stop_code 0', 'blocked_move 0', 'context_notes 0', 'memory_used 0', 'started_via 0', 0.25, 0.25, 'restarts 0', 'diagnosis 0', '2025-03-01T10:00:00.000000+00:00', 'retries 0', 'account-0', 'model_override 0', 'effort_override 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_run-1', 'p-2', 'ticket-1', 'member-1', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, NULL, 1.75, true, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, true, NULL, NULL, true, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL),
	('ai_run-2', 'p-missing', 'missing-parent', 'missing-parent', 14, '', '', '', '', '', 'missing-parent', 'missing-parent', false, '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', '', '', 14, 14, 14, 3.25, false, 14, 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, '2025-05-05T05:05:05.555555+00:00', 'missing-parent', false, 14, 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 3.25, 3.25, '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_run_transcript VALUES
	('ai_run_transcript-0', 'p-1', 'member-0', 'path 0', 0, 0, false, 'pinned_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_run_transcript-1', 'p-2', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, true, NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('ai_run_transcript-2', 'p-missing', 'missing-parent', '', 14, 14, false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_schedule VALUES
	('ai_schedule-0', 'p-1', 'ticket-0', 'member-0', 'backup_member-0', 'created_by 0', 'kind 0', '2025-03-01T10:00:00.000000+00:00', 'days 0', 'time 0', 'tz 0', 'ends 0', 0, 'ends_on 0', 'window_end 0', 'checks 0', 'review 0', 'limits 0', 'catch_up 0', 0.25, 'notify 0', 'notify_people 0', 'instruction 0', 'state 0', 'paused_reason 0', 0, 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_schedule-1', 'p-2', 'ticket-1', 'member-1', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 1.75, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 7, 7, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_schedule-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '2025-05-05T05:05:05.555555+00:00', '', '', '', '', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', '', 3.25, '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_schedule_run VALUES
	('ai_schedule_run-0', 'schedule-0', 'p-1', 'ticket-0', '2025-03-01T10:00:00.000000+00:00', 'state 0', false, 'member-0', 'run_ids 0', 0, 0, 'results 0', 'review 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 0, 0.25, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_schedule_run-1', 'schedule-1', 'p-2', 'ticket-1', '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 7, 1.75, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_schedule_run-2', 'missing-parent', 'p-missing', 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '', false, 'missing-parent', '', 14, 14, '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 14, 3.25, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_skill_use VALUES
	(1, 'run-0', 'p-1', 'member-0', 'kind 0', 'name 0', 'plugin 0', '2025-03-01T10:00:00.000000+00:00'),
	(2, 'run-1', 'p-2', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	(3, 'missing-parent', 'p-missing', 'missing-parent', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_standing_order VALUES
	('ai_standing_order-0', 'p-1', 'name 0', 'sentence 0', 'rule 0', 'state 0', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 0, 0, '2025-03-01T10:00:00.000000+00:00', 'last_summary 0', 'template 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_standing_order-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, NULL, NULL, 7, 7, NULL, NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00'),
	('ai_standing_order-2', 'p-missing', '', '', '', '', 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 14, 14, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_ticket_flag VALUES
	('ai_ticket_flag-0', 'ticket-0', 'p-1', 'kind 0', 'data 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'resolved_by 0', 'resolution 0'),
	('ai_ticket_flag-1', 'ticket-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL),
	('ai_ticket_flag-2', 'missing-parent', 'p-missing', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_ticket_pace VALUES
	('ai_ticket_pace-0', 'p-1', 'pace 0', 'set_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('ai_ticket_pace-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('ai_ticket_pace-2', 'p-missing', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_ticket_step VALUES
	('ai_ticket_step-0', 'ticket-0', 0, 0, 'key 0', 'label 0', 'kind 0', 'role 0', 'state 0', 0, 'member-0', 'run-0', 'note_in 0', 'note 0', 'outcome 0', 'result 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_ticket_step-1', 'ticket-1', 7, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('ai_ticket_step-2', 'missing-parent', 14, 14, '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 14, 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_ticket_workflow VALUES
	('ai_ticket_workflow-0', 'p-1', 'template_key 0', 'template_name 0', 0, 'steps 0', 'state 0', 'stop_reason 0', 'stop_detail 0', 'review_depth 0', 'depth_by 0', 'depth_note 0', 'pace 0', 'rounds 0', 'objections 0', 'rulings 0', 'arbitration_run-0', 'reviewer-0', 0, 'attached_by 0', 'meta 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_ticket_workflow-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 7, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ai_ticket_workflow-2', 'p-missing', '', '', 14, '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', 'missing-parent', 'missing-parent', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_usage VALUES
	('ai_usage-0', 'p-1', 'feature 0', 'member-0', 'person 0', 0.25, 0, 0, false, '2025-03-01T10:00:00.000000+00:00'),
	('ai_usage-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 1.75, 7, 7, true, '2025-04-01T00:00:00.000000+00:00'),
	('ai_usage-2', 'p-missing', '', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 3.25, 14, 14, false, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_watched_pr VALUES
	('ai_watched_pr-0', 'p-1', 0, 'url 0', 'branch 0', 'repo 0', 'state 0', 'ci 0', 'red 0', 'seen_comments 0', 'pending_comments 0', '2025-03-01T10:00:00.000000+00:00', 'last_error 0'),
	('ai_watched_pr-1', 'p-2', 7, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL),
	('ai_watched_pr-2', 'p-missing', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_workflow_template VALUES
	('ai_workflow_template-0', 'p-1', 'key 0', 'name 0', 0, 'body 0', 'history 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0'),
	('ai_workflow_template-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00', NULL),
	('ai_workflow_template-2', 'p-missing', '', '', 14, '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO ai_workspace_defaults VALUES
	(1, 'template 0', 'ceiling 0', 'delete_mode 0', 0.25, 0.25, 'updated_by 0', '2025-03-01T10:00:00.000000+00:00'),
	(2, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL),
	(3, '', '', '', 3.25, 3.25, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ai_worktree VALUES
	('ai_worktree-0', 'p-1', 'repo 0', 'path 0', 'branch 0', 'base 0', 0, 'state 0', 'handover 0', 'pr_url 0', 0, 'conflict_files 0', '2025-03-01T10:00:00.000000+00:00', 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ai_worktree-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('ai_worktree-2', 'p-missing', '', '', '', '', 14, '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '', '2025-05-05T05:05:05.555555+00:00', 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO alembic_version VALUES
	('e8b0d2f4a6c9');



INSERT INTO canvas VALUES
	('canvas-0', 'p-1', 'owner_kind 0', 'owner-0', 'page-0', 'title 0', 0, 0, 0, 0, 'created_by 0', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'deleted_by 0'),
	('canvas-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'owner-1', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 7, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('canvas-2', 'p-missing', '', 'missing-parent', 'missing-parent', '', 14, 14, 14, 14, '', '2025-05-05T05:05:05.555555+00:00', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO canvas_comment VALUES
	('canvas_comment-0', 'thread-0', 'author 0', 'body 0', 'mentions 0', 'ai 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('canvas_comment-1', 'thread-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00', NULL),
	('canvas_comment-2', 'missing-parent', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO canvas_proposal VALUES
	('canvas_proposal-0', 'canvas-0', 'author 0', 'member-0', 'job-0', 'request 0', 'note 0', 'status 0', 'changes 0', 0, '2025-03-01T10:00:00.000000+00:00', 'decided_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('canvas_proposal-1', 'canvas-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('canvas_proposal-2', 'missing-parent', '', 'missing-parent', 'missing-parent', '', '', '', '', 14, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO canvas_thread VALUES
	('canvas_thread-0', 'canvas-0', 0, 'board-0', 0.25, 0.25, 'page 0', 'anchor 0', 'status 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', 'resolved_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('canvas_thread-1', 'canvas-1', 7, NULL, 1.75, 1.75, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('canvas_thread-2', 'missing-parent', 14, 'missing-parent', 3.25, 3.25, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO canvas_version VALUES
	('canvas_version-0', 'canvas-0', 0, 'name 0', 'reason 0', 'author 0', 'note 0', 'changes 0', 'summary 0', 'doc 0', '2025-03-01T10:00:00.000000+00:00'),
	('canvas_version-1', 'canvas-1', 7, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('canvas_version-2', 'missing-parent', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO diagram VALUES
	('diagram-0', 'p-1', 'label 0', 'summary 0', 'item_kind 0', 'item-0', 0, 'created_by 0', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'deleted_by 0'),
	('diagram-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('diagram-2', 'p-missing', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 14, '', '2025-05-05T05:05:05.555555+00:00', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO diagram_settings VALUES
	(1, 'mode 0', 'url 0'),
	(2, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	(3, '', '');



INSERT INTO diagram_version VALUES
	('diagram_version-0', 'diagram-0', 0, 'source 0', 'svg 0', 'preview_kind 0', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00'),
	('diagram_version-1', 'diagram-1', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('diagram_version-2', 'missing-parent', 14, '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_ai_check VALUES
	('docs_ai_check-0', 'p-1', 'state 0', 'reasons 0', 0, 'deps_hash 0', '2025-03-01T10:00:00.000000+00:00', 'ok_until 0', 'ok_hash 0', 'dismissed 0', 'job-0'),
	('docs_ai_check-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL),
	('docs_ai_check-2', 'p-missing', '', '', 14, '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'missing-parent');



INSERT INTO docs_ai_health VALUES
	('docs_ai_health-0', 'data 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('docs_ai_health-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL),
	('docs_ai_health-2', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_ai_ignore VALUES
	('docs_ai_ignore-0', 'docs_ai_ignore-0', 'by 0', '2025-03-01T10:00:00.000000+00:00'),
	('docs_ai_ignore-1', 'docs_ai_ignore-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('docs_ai_ignore-2', 'docs_ai_ignore-2', '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_ai_job VALUES
	('docs_ai_job-0', 'p-1', 'page-0', 'thread-0', 'comment-0', 'member-0', 'kind 0', 'state 0', 'started_by 0', 'instruction 0', 'session-0', 'reads 0', 'steps 0', 'result 0', 'error 0', 0, 0, 0.25, false, 'reply_comment-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('docs_ai_job-1', 'p-2', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 1.75, true, NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('docs_ai_job-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '', '', 'missing-parent', '', '', '', '', 14, 14, 3.25, false, 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_ai_proposal VALUES
	('docs_ai_proposal-0', 'p-1', 'page-0', 'member-0', 'run-0', 'job-0', 'ticket-0', 'approval-0', 'on_behalf_of 0', 0, 'status 0', 'summary 0', 'changes 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'decided_by 0', '2025-03-01T10:00:00.000000+00:00', 'decision_note 0'),
	('docs_ai_proposal-1', 'p-2', 'page-1', 'member-1', NULL, NULL, NULL, NULL, NULL, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL, NULL),
	('docs_ai_proposal-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO docs_ai_session VALUES
	('docs_ai_session-0', 'docs_ai_session-0', 'p-1', 'session-0', 0, '2025-03-01T10:00:00.000000+00:00'),
	('docs_ai_session-1', 'docs_ai_session-1', 'p-2', 'session-1', 7, '2025-04-01T00:00:00.000000+00:00'),
	('docs_ai_session-2', 'docs_ai_session-2', 'p-missing', 'missing-parent', 14, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_ai_settings VALUES
	('docs_ai_settings-0', false, 'member-0', 'read_scope 0', 'picked_pages 0', 'style_page-0', 'edits_mode 0', 0, false, 0, false, 'updated_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('docs_ai_settings-1', true, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, true, 7, true, NULL, '2025-04-01T00:00:00.000000+00:00'),
	('docs_ai_settings-2', false, 'missing-parent', '', '', 'missing-parent', '', 14, false, 14, false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_anchor_aliases VALUES
	('docs_anchor_aliases-0', 'page-0', 'old_slug 0', 'new_slug 0'),
	('docs_anchor_aliases-1', 'page-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('docs_anchor_aliases-2', 'missing-parent', '', '');



INSERT INTO docs_comment VALUES
	('docs_comment-0', 'thread-0', 'author 0', 'body 0', 'mentions 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'ai 0'),
	('docs_comment-1', 'thread-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('docs_comment-2', 'missing-parent', '', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO docs_comment_event VALUES
	('docs_comment_event-0', 'p-1', 'page-0', 'thread-0', 'comment-0', 'kind 0', 'actor 0', 'mentioned 0', 'recipients 0', 'page_title 0', 'snippet 0', '2025-03-01T10:00:00.000000+00:00'),
	('docs_comment_event-1', 'p-2', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('docs_comment_event-2', 'p-missing', 'missing-parent', 'missing-parent', 'missing-parent', '', '', '', '', '', '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_comment_read VALUES
	('docs_comment_read-0', 'thread-0', 'reader 0', '2025-03-01T10:00:00.000000+00:00'),
	('docs_comment_read-1', 'thread-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('docs_comment_read-2', 'missing-parent', '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_comment_thread VALUES
	('docs_comment_thread-0', 'page-0', 'kind 0', 'status 0', 'anchor_quote 0', 'anchor_prefix 0', 'anchor_suffix 0', 'anchor_section 0', 'anchor_state 0', 0, 'created_by 0', '2025-03-01T10:00:00.000000+00:00', 'resolved_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('docs_comment_thread-1', 'page-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('docs_comment_thread-2', 'missing-parent', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 14, '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_draft VALUES
	('docs_draft-0', 'page-0', 'author 0', 'title 0', 'markdown 0', 0, 0, '2025-03-01T10:00:00.000000+00:00', 'ai_source 0'),
	('docs_draft-1', 'page-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, '2025-04-01T00:00:00.000000+00:00', NULL),
	('docs_draft-2', 'missing-parent', '', '', '', 14, 14, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('d-1', 'pg-draft', 'author 0', 'title 0', '## Draft heading
body', 0, 0, '2025-03-01T10:00:00.000000+00:00', 'ai_source 0'),
	('d-2', 'pg-published', 'author 0', 'title 0', '## Draft of a published page', 0, 0, '2025-03-01T10:00:00.000000+00:00', 'ai_source 0'),
	('d-3', 'pg-wrong-version', 'author 0', 'title 0', '# From the draft ## after a line separator', 0, 0, '2025-03-01T10:00:00.000000+00:00', 'ai_source 0');



INSERT INTO docs_link VALUES
	('docs_link-0', 'source_page-0', 'source_section 0', 'target_page-0', 'target_title 0', 'target_anchor 0', 'target_ticket-0', 'display_text 0', 'snippet 0', 'origin 0'),
	('docs_link-1', 'source_page-1', NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('docs_link-2', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '');



INSERT INTO docs_page VALUES
	('docs_page-0', 'p-1', 'parent-0', 0, 'title 0', 'slug 0', 'status 0', 0, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0'),
	('docs_page-1', 'p-2', NULL, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('docs_page-2', 'p-missing', 'missing-parent', 14, '', '', '', 14, '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', false, false, ''),
	('pg-published', 'p-1', 'parent-0', 0, 'Published page', 'slug 0', 'status 0', 2, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', NULL, 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0'),
	('pg-draft', 'p-1', 'parent-0', 0, 'Only a draft', 'slug 0', 'status 0', 0, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', NULL, 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0'),
	('pg-empty', 'p-2', 'parent-0', 0, 'Nothing written ü', 'slug 0', 'status 0', 0, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', NULL, 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0'),
	('pg-deleted', 'p-1', 'parent-0', 0, 'In the bin', 'slug 0', 'status 0', 1, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0'),
	('pg-wrong-version', 'p-1', 'parent-0', 0, 'Version row missing', 'slug 0', 'status 0', 7, 'created_by 0', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', NULL, 'deleted_by 0', 'deleted_root-0', false, false, 'kind 0');



INSERT INTO docs_page_seen VALUES
	('docs_page_seen-0', 'page-0', 'viewer 0', 0, '2025-03-01T10:00:00.000000+00:00'),
	('docs_page_seen-1', 'page-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, '2025-04-01T00:00:00.000000+00:00'),
	('docs_page_seen-2', 'missing-parent', '', 14, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO docs_title_aliases VALUES
	('docs_title_aliases-0', 'page-0', 'old_title 0'),
	('docs_title_aliases-1', 'page-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('docs_title_aliases-2', 'missing-parent', '');



INSERT INTO docs_version VALUES
	('docs_version-0', 'page-0', 0, 'title 0', 'markdown 0', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', 'diagram_versions 0', false),
	('docs_version-1', 'page-1', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true),
	('docs_version-2', 'missing-parent', 14, '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '', false),
	('v-1', 'pg-published', 1, 'title 0', '# Old title

old', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', 'diagram_versions 0', false),
	('v-2', 'pg-published', 2, 'title 0', '# One *big* title #
text
```
# not a heading
```
## [[Other page#part|shown]] and [a link](http://x)
#nospace
### ==mark== `code` ~~gone~~
   ~~~
## in a fence
~~~
###### Tiêu đề sâu 日本語 ##
####### seven
#	 Tabbed
## 
## [[Plain]] __bold__
', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', 'diagram_versions 0', false),
	('v-3', 'pg-deleted', 1, 'title 0', '# Deleted', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', 'diagram_versions 0', false),
	('v-4', 'pg-wrong-version', 1, 'title 0', '# Not the current version', 'author 0', 'note 0', '2025-03-01T10:00:00.000000+00:00', 'diagram_versions 0', false);



INSERT INTO idea_advice VALUES
	('idea_advice-0', 'idea-0', 'action 0', 'reason 0', 'confidence 0', 'target-0', 'archive_reason 0', 0, 'idea_stamp 0', 'member-0', 0.25, 'state 0', '2025-03-01T10:00:00.000000+00:00'),
	('idea_advice-1', 'idea-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 1.75, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('idea_advice-2', 'missing-parent', '', '', '', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '', 'missing-parent', 3.25, '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_ai_settings VALUES
	('idea_ai_settings-0', false, false, false, false, false, false, 0.25, '2025-03-01T10:00:00.000000+00:00'),
	('idea_ai_settings-1', true, true, true, true, true, true, 1.75, '2025-04-01T00:00:00.000000+00:00'),
	('idea_ai_settings-2', false, false, false, false, false, false, 3.25, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_assumption VALUES
	('idea_assumption-0', 'idea-0', 0, 'text 0', 'impact 0', 'status 0', 'test_ticket-0', false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('idea_assumption-1', 'idea-1', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, true, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('idea_assumption-2', 'missing-parent', 14, '', '', '', 'missing-parent', false, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_comment VALUES
	('idea_comment-0', 'idea-0', 'author 0', 'body 0', false, 'run-0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('idea_comment-1', 'idea-1', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, '2025-04-01T00:00:00.000000+00:00', NULL),
	('idea_comment-2', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', false, 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_counter VALUES
	(1, 0),
	(2, 7),
	(3, 14);



INSERT INTO idea_digest VALUES
	('idea_digest-0', 'p-1', 'text 0', 'items 0', false, 'member-0', 0.25, 0, '2025-03-01T10:00:00.000000+00:00'),
	('idea_digest-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, 1.75, 7, '2025-04-01T00:00:00.000000+00:00'),
	('idea_digest-2', 'p-missing', '', '', false, 'missing-parent', 3.25, 14, '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_evidence VALUES
	('idea_evidence-0', 'assumption-0', 'kind 0', 'title 0', 'ref 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00'),
	('idea_evidence-1', 'assumption-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('idea_evidence-2', 'missing-parent', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_log_entry VALUES
	('idea_log_entry-0', 'idea-0', 'kind 0', 'body 0', 'author 0', false, false, 'assumption-0', 'attachments 0', 'ticket-0', '2025-03-01T10:00:00.000000+00:00'),
	('idea_log_entry-1', 'idea-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, true, true, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00'),
	('idea_log_entry-2', 'missing-parent', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, false, 'missing-parent', '', 'missing-parent', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO idea_ticket VALUES
	('idea_ticket-0', 'p-1', 'title 0', 'description 0', 'idea_status 0', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'promoted_to_ticket-0', '2025-03-01T10:00:00.000000+00:00', 'activity_trail 0', 'microthoughts 0', 'assumptions 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('idea_ticket-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 7, 7, 7, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('idea_ticket-2', 'p-missing', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '', 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, 14, 14, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'missing-parent', '2025-05-05T05:05:05.555555+00:00', '', '', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00'),
	('i-dropped', 'p-1', 'Idea i-dropped', 'description 0', 'dropped', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-dropped-revisit', 'p-1', 'Idea i-dropped-revisit', 'description 0', 'dropped', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, '2025-12-01', '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-none', 'p-1', 'Idea i-approved-none', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-empty', 'p-1', 'Idea i-approved-empty', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', '', NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-gone', 'p-1', 'Idea i-approved-gone', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', 't-missing', '2025-03-01T10:00:00.000000+00:00', '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-done', 'p-1', 'Idea i-approved-done', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', 't-done', '2025-03-01T10:00:00.000000+00:00', '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-wontdo', 'p-1', 'Idea i-approved-wontdo', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', 't-wontdo', '2025-03-01T10:00:00.000000+00:00', '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-open', 'p-1', 'Idea i-approved-open', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', 't-open', '2025-03-01T10:00:00.000000+00:00', '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-none-revisit', 'p-1', 'Idea i-approved-none-revisit', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, ' 2025-12-02 ', '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-approved-nobody-revisit', 'p-1', 'Idea i-approved-nobody-revisit', 'description 0', 'approved', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, '2025-12-03', '2025-03-01T10:00:00.000000+00:00', 't-nobody', NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-draft-fresh', 'p-1', 'Idea i-draft-fresh', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-draft-no-trail', 'p-1', 'Idea i-draft-no-trail', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', ''),
	('i-draft-touched', 'p-1', 'Idea i-draft-touched', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-draft-micro', 'p-1', 'Idea i-draft-micro', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[{"id": "mt-1", "text": "  a thought  ", "at": "2025-01-02T00:00:00+00:00"}, {"text": "no id, no time \u00e9"}, {"id": "mt-3", "text": "   "}, "not an object", {"id": 7, "text": 12.5}, {"id": "mt-null", "text": null}, {"id": "mt-bool", "text": true, "at": ""}, {"id": "", "text": "empty id"}, {"id": "mt-missing-text"}]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-draft-assume', 'p-1', 'Idea i-draft-assume', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[{"id": "as-1", "text": "users want it", "status": "validated", "at": "2025-01-03T00:00:00+00:00"}, {"text": " cheap to build ", "status": "invalidated"}, {"id": "as-3", "text": "x", "status": "untested"}, {"id": "as-4", "text": "y", "status": "weird"}, {"id": "as-5", "text": "z"}, {"id": "as-6", "text": ""}, 5, {"id": "as-7", "text": "status is a number", "status": 3}, {"id": "as-8", "text": 0, "status": null, "at": 0}]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-draft-revisit', 'p-1', 'Idea i-draft-revisit', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, '2025-12-04', '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-review', 'p-1', 'Idea i-review', 'description 0', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[{"id": "mu-1", "text": "  a thought  ", "at": "2025-01-02T00:00:00+00:00"}, {"text": "no id, no time \u00e9"}, {"id": "mu-3", "text": "   "}, "not an object", {"id": 8, "text": 12.5}, {"id": "mu-null", "text": null}, {"id": "mu-bool", "text": true, "at": ""}, {"id": "", "text": "empty id"}, {"id": "mu-missing-text"}]', '[{"id": "at-1", "text": "users want it", "status": "validated", "at": "2025-01-03T00:00:00+00:00"}, {"text": " cheap to build ", "status": "invalidated"}, {"id": "at-3", "text": "x", "status": "untested"}, {"id": "at-4", "text": "y", "status": "weird"}, {"id": "at-5", "text": "z"}, {"id": "at-6", "text": ""}, 5, {"id": "at-7", "text": "status is a number", "status": 3}, {"id": "at-8", "text": 0, "status": null, "at": 0}]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-review-revisit', 'p-1', 'Idea i-review-revisit', 'description 0', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, '   ', '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-review-wontdo', 'p-1', 'Idea i-review-wontdo', 'description 0', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', 't-wontdo2', NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-old-raw', 'p-1', 'Idea i-old-raw', 'description 0', 'raw', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', '#F5C518', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-old-brewing', 'p-1', 'Idea i-old-brewing', 'description 0', 'brewing', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'orange', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-old-validated', 'p-1', 'Idea i-old-validated', 'description 0', 'validated', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'teal', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-unknown', 'p-1', 'Idea i-unknown', 'description 0', 'something else', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'yellow', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-bad-json', 'p-1', 'Idea i-bad-json', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, 'not json', '{"a": 1}', 'null', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-empty-json', 'p-1', 'Idea i-empty-json', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '', '', '', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-body', 'p-1', 'Idea i-body', '  What it is
second line  ', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'high', 'tags 0', '  Why it matters ü  ', 5, 1, 4, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "u1", "label": "T\u1ea1o \u00fd t\u01b0\u1edfng \ud83d\udca1", "at": "2025-01-01", "author": null, "n": 1.0, "f": 0.1, "big": 12345678901234567890, "neg": -1.5e-07, "nested": {"b": [true, false, null], "a": "\u00e9"}}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-problem-only', 'p-1', 'Idea i-problem-only', '', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'Only a problem', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-description-only', 'p-1', 'Idea i-description-only', 'Only a description', 'in_review', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', '', 'tags 0', NULL, 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00'),
	('i-no-project', 'p-missing', 'Idea i-no-project', 'description 0', 'draft', 'stage 0', 'park_until 0', 'archive_reason 0', 'source 0', 'source_ref 0', 'created_by 0', 'owner 0', 'park_note 0', 'archive_note 0', '2025-03-01T10:00:00.000000+00:00', 'prev_state 0', 'merged_into-0', '2025-03-01T10:00:00.000000+00:00', 'merge_undo 0', '2025-03-01T10:00:00.000000+00:00', 'outcome 0', 'outcome_note 0', 'former_ticket-0', 'effort_guess 0', 'workspace_retention 0', 'body 0', 'details 0', 'idea_color 0', 'idea_emoji 0', 'idea_energy 0', 'tags 0', 'problem_statement 0', 0, 0, 0, NULL, '2025-03-01T10:00:00.000000+00:00', NULL, NULL, '[{"id": "tr-0", "label": "Step 0 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}, {"id": "tr-1", "label": "Step 1 \u2014 \u2713", "at": "2025-01-01T00:00:00+00:00", "author": "Minh"}]', '[]', '[]', '2025-03-01T10:00:00.000000+00:00', '2025-03-02T10:00:00.000000+00:00');



INSERT INTO idea_vote VALUES
	('idea_vote-0', 'idea-0', 'voter 0', '2025-03-01T10:00:00.000000+00:00'),
	('idea_vote-1', 'idea-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('idea_vote-2', 'missing-parent', '', '2025-05-05T05:05:05.555555+00:00');






INSERT INTO member VALUES
	('member-0', 'p-1', 'name 0', 'color 0', 'role 0', 'kind 0', '2025-03-01T10:00:00.000000+00:00'),
	('member-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('member-2', 'p-missing', '', '', '', '', '2025-05-05T05:05:05.555555+00:00'),
	('m-human', 'p-1', 'Ann', '#111111', 'role 0', 'human', '2025-03-01T10:00:00.000000+00:00'),
	('m-ai', 'p-1', 'Bot', '#222222', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-ai-removed', 'p-1', 'Old bot', '#333333', 'role 0', 'ai_removed', '2025-03-01T10:00:00.000000+00:00'),
	('m-claude-code', 'p-2', 'claude-code', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-anthropic', 'p-2', 'anthropic', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-antigravity', 'p-2', 'antigravity', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-openai', 'p-2', 'openai', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-gemini', 'p-2', 'gemini', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-custom', 'p-2', 'custom', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-mcp-client', 'p-2', 'mcp-client', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-unknown', 'p-2', 'unknown', '#000000', 'role 0', 'ai', '2025-03-01T10:00:00.000000+00:00'),
	('m-human-with-profile', 'p-2', 'Not AI', '#444444', 'role 0', 'human', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO notification VALUES
	('notification-0', 'recipient 0', 0, 0, 'p-1', 'kind 0', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('notification-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, true, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('notification-2', '', 14, 14, 'p-missing', '', false, '', 14, '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', false, false, '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00'),
	('n-page_proposal', 'user', 0, 0, 'p-1', 'page_proposal', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-approval', 'user', 0, 0, 'p-1', 'approval', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-blocked', 'user', 0, 0, 'p-1', 'blocked', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-run_restarted', 'user', 0, 0, 'p-1', 'run_restarted', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-story_plan', 'user', 0, 0, 'p-1', 'story_plan', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-story_blocked', 'user', 0, 0, 'p-1', 'story_blocked', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-story_done', 'user', 0, 0, 'p-1', 'story_done', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-mention', 'user', 0, 0, 'p-1', 'mention', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('n-ai_done', 'user', 0, 0, 'p-1', 'ai_done', false, 'group_key 0', 0, 'items 0', 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', false, false, '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'done_reason 0', 'done_by 0', 'snoozed_until 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO notify_event VALUES
	(1, 'p-1', 'kind 0', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(2, 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, NULL, NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	(3, 'p-missing', '', '', false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', '', '', '2025-05-05T05:05:05.555555+00:00'),
	(100, 'p-1', 'page_proposal', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(101, 'p-1', 'approval', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(102, 'p-1', 'blocked', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(103, 'p-1', 'run_restarted', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(104, 'p-1', 'story_plan', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(105, 'p-1', 'story_blocked', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(106, 'p-1', 'story_done', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00'),
	(107, 'p-1', 'mention', 'op 0', false, 'target_kind 0', 'target-0', 'ticket-0', 'page-0', 'member-0', 'actor 0', 'title 0', 'body 0', 'data 0', 'recipients 0', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO notify_follow VALUES
	('notify_follow-0', 'recipient 0', 'scope 0', 'scope-0', 'p-1', 'level 0', 'until 0', 'label 0', '2025-03-01T10:00:00.000000+00:00'),
	('notify_follow-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'scope-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('notify_follow-2', '', '', 'missing-parent', 'p-missing', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '2025-05-05T05:05:05.555555+00:00'),
	('nf-1', 'user', 'kind', 'approval', 'p-1', 'level 0', 'until 0', 'label 0', '2025-03-01T10:00:00.000000+00:00'),
	('nf-2', 'user', 'kind', 'mention', 'p-1', 'level 0', 'until 0', 'label 0', '2025-03-01T10:00:00.000000+00:00'),
	('nf-3', 'user', 'space', 'approval', 'p-1', 'level 0', 'until 0', 'label 0', '2025-03-01T10:00:00.000000+00:00'),
	('nf-4', 'ann', 'kind', 'story_done', 'p-1', 'level 0', 'until 0', 'label 0', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO notify_prefs VALUES
	('notify_prefs-0', 'prefs 0', '2025-03-01T10:00:00.000000+00:00'),
	('notify_prefs-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00'),
	('notify_prefs-2', '', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO project VALUES
	('project-0', 'name 0', 'GEN0', 'color 0', 0, 'repo_path 0', 'worktree_template 0', false, false, 'docs_edit_policy 0'),
	('project-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'GEN1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, NULL, NULL, true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back'),
	('project-2', '', 'GEN2', '', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', false, false, ''),
	('p-1', 'One', 'ONE', 'color 0', 0, 'repo_path 0', 'worktree_template 0', false, false, 'docs_edit_policy 0'),
	('p-2', 'Two ü', 'TWO', 'color 0', 0, 'repo_path 0', 'worktree_template 0', false, false, 'docs_edit_policy 0');



INSERT INTO sketch VALUES
	('sketch-0', 'p-1', 'owner_kind 0', 'owner-0', 'title 0', 0, 0, 0, 0, 0, 0, 'created_by 0', '2025-03-01T10:00:00.000000+00:00', 'updated_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', 'deleted_by 0'),
	('sketch-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'owner-1', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, 7, 7, 7, 7, 7, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-04-01T00:00:00.000000+00:00', NULL, NULL),
	('sketch-2', 'p-missing', '', 'missing-parent', '', 14, 14, 14, 14, 14, 14, '', '2025-05-05T05:05:05.555555+00:00', '', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back');



INSERT INTO story VALUES
	('story-0', 'p-1', 'state 0', 'approve 0', 0, 'pm-0', 'plan 0', false, 'review_note 0', 'history 0', 'meta 0', 'created_by 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('story-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 7, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, '2025-04-01T00:00:00.000000+00:00', NULL, NULL, NULL),
	('story-2', 'p-missing', '', '', 14, 'missing-parent', '', false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00');



INSERT INTO ticket VALUES
	('ticket-0', 'p-1', 'title 0', 'description 0', 'type 0', 'status 0', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', 'assignee 0', 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('ticket-1', 'p-2', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL, NULL, 7, NULL, NULL, NULL, 'Tên ô 💡 日本語 ''quote'' "double" \ back', true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-04-01T00:00:00.000000+00:00', '2025-04-01T00:00:00.000000+00:00'),
	('ticket-2', 'p-missing', '', '', '', '', '', 3.25, '2025-05-05T05:05:05.555555+00:00', '', 'missing-parent', '', '', '', '', '', '', '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', '', false, false, '', '', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 14, '2025-05-05T05:05:05.555555+00:00', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', '', false, 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'Tên ô 💡 日本語 ''quote'' "double" \ back', 'missing-parent', 'missing-parent', 14, 'Tên ô 💡 日本語 ''quote'' "double" \ back', '2025-05-05T05:05:05.555555+00:00', '2025-05-05T05:05:05.555555+00:00'),
	('t-done', 'p-1', 'title 0', 'description 0', 'type 0', 'done', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', 'm-human', 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('t-wontdo', 'p-1', 'title 0', 'description 0', 'type 0', 'wont_do', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', 'm-ai', 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('t-wontdo2', 'p-1', 'title 0', 'description 0', 'type 0', 'wont_do', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', 'm-ai-removed', 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('t-open', 'p-1', 'title 0', 'description 0', 'type 0', 'in-progress', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', 'm-gone', 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00'),
	('t-nobody', 'p-2', 'title 0', 'description 0', 'type 0', 'todo', 'priority 0', 0.25, '2025-03-01T10:00:00.000000+00:00', 'tags 0', 'parent-0', 'comments 0', 'acceptance_criteria 0', 'sub_tasks 0', 'activity_log 0', 'work_log 0', 'test_cases 0', '2025-03-01T10:00:00.000000+00:00', 'wont_do_reason 0', 'created_by 0', NULL, 'blocks 0', 'blocked_by 0', false, false, 'links 0', 'branches 0', 0, 'repo_path 0', 0, '2025-03-01T10:00:00.000000+00:00', 'last_reopened_by 0', 'last_reopen_reason 0', 'reopen_history 0', false, 'pending_reason_type 0', 'pending_ticket-0', 'pending_member-0', 'pending_party 0', 'pending_note 0', 'pending_since 0', 'pending_by 0', 'from_idea-0', 'tests_assumption-0', 0, 'review_requested_from 0', '2025-03-01T10:00:00.000000+00:00', '2025-03-01T10:00:00.000000+00:00');



INSERT INTO workspace_settings VALUES
	(1, false, 'root_path 0', 0),
	(2, true, 'Tên ô 💡 日本語 ''quote'' "double" \ back', NULL),
	(3, false, '', 14);



SELECT pg_catalog.setval('ai_skill_use_id_seq', 1, false);



SELECT pg_catalog.setval('kanban_change_id_seq', 1, false);



SELECT pg_catalog.setval('notify_event_id_seq', 1, false);



ALTER TABLE ONLY ai_account
    ADD CONSTRAINT ai_account_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_account_state
    ADD CONSTRAINT ai_account_state_pkey PRIMARY KEY (key);



ALTER TABLE ONLY ai_approval
    ADD CONSTRAINT ai_approval_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_assist_settings
    ADD CONSTRAINT ai_assist_settings_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_audit
    ADD CONSTRAINT ai_audit_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_chat_message
    ADD CONSTRAINT ai_chat_message_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_chat
    ADD CONSTRAINT ai_chat_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_config_state
    ADD CONSTRAINT ai_config_state_pkey PRIMARY KEY (member_id);



ALTER TABLE ONLY ai_decision
    ADD CONSTRAINT ai_decision_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_digest
    ADD CONSTRAINT ai_digest_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_draft
    ADD CONSTRAINT ai_draft_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_eval_mark
    ADD CONSTRAINT ai_eval_mark_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_grant
    ADD CONSTRAINT ai_grant_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_insight
    ADD CONSTRAINT ai_insight_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_knowledge_doc
    ADD CONSTRAINT ai_knowledge_doc_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_lesson
    ADD CONSTRAINT ai_lesson_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_library_item
    ADD CONSTRAINT ai_library_item_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_member
    ADD CONSTRAINT ai_member_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_memory_note
    ADD CONSTRAINT ai_memory_note_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_notification
    ADD CONSTRAINT ai_notification_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_order_firing
    ADD CONSTRAINT ai_order_firing_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_plugin
    ADD CONSTRAINT ai_plugin_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_project_knowledge
    ADD CONSTRAINT ai_project_knowledge_pkey PRIMARY KEY (project_id);



ALTER TABLE ONLY ai_project_settings
    ADD CONSTRAINT ai_project_settings_pkey PRIMARY KEY (project_id);



ALTER TABLE ONLY ai_repo_scan
    ADD CONSTRAINT ai_repo_scan_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_role_pack
    ADD CONSTRAINT ai_role_pack_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_run
    ADD CONSTRAINT ai_run_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_run_transcript
    ADD CONSTRAINT ai_run_transcript_pkey PRIMARY KEY (run_id);



ALTER TABLE ONLY ai_schedule
    ADD CONSTRAINT ai_schedule_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_schedule_run
    ADD CONSTRAINT ai_schedule_run_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_skill_use
    ADD CONSTRAINT ai_skill_use_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_standing_order
    ADD CONSTRAINT ai_standing_order_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_ticket_flag
    ADD CONSTRAINT ai_ticket_flag_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_ticket_pace
    ADD CONSTRAINT ai_ticket_pace_pkey PRIMARY KEY (ticket_id);



ALTER TABLE ONLY ai_ticket_step
    ADD CONSTRAINT ai_ticket_step_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_ticket_workflow
    ADD CONSTRAINT ai_ticket_workflow_pkey PRIMARY KEY (ticket_id);



ALTER TABLE ONLY ai_usage
    ADD CONSTRAINT ai_usage_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_watched_pr
    ADD CONSTRAINT ai_watched_pr_pkey PRIMARY KEY (ticket_id);



ALTER TABLE ONLY ai_workflow_template
    ADD CONSTRAINT ai_workflow_template_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_workspace_defaults
    ADD CONSTRAINT ai_workspace_defaults_pkey PRIMARY KEY (id);



ALTER TABLE ONLY ai_worktree
    ADD CONSTRAINT ai_worktree_pkey PRIMARY KEY (ticket_id);



ALTER TABLE ONLY alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);



ALTER TABLE ONLY canvas_comment
    ADD CONSTRAINT canvas_comment_pkey PRIMARY KEY (id);



ALTER TABLE ONLY canvas
    ADD CONSTRAINT canvas_pkey PRIMARY KEY (id);



ALTER TABLE ONLY canvas_proposal
    ADD CONSTRAINT canvas_proposal_pkey PRIMARY KEY (id);



ALTER TABLE ONLY canvas_thread
    ADD CONSTRAINT canvas_thread_pkey PRIMARY KEY (id);



ALTER TABLE ONLY canvas_version
    ADD CONSTRAINT canvas_version_pkey PRIMARY KEY (id);



ALTER TABLE ONLY diagram
    ADD CONSTRAINT diagram_pkey PRIMARY KEY (id);



ALTER TABLE ONLY diagram_settings
    ADD CONSTRAINT diagram_settings_pkey PRIMARY KEY (id);



ALTER TABLE ONLY diagram_version
    ADD CONSTRAINT diagram_version_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_ai_check
    ADD CONSTRAINT docs_ai_check_pkey PRIMARY KEY (page_id);



ALTER TABLE ONLY docs_ai_health
    ADD CONSTRAINT docs_ai_health_pkey PRIMARY KEY (project_id);



ALTER TABLE ONLY docs_ai_ignore
    ADD CONSTRAINT docs_ai_ignore_pkey PRIMARY KEY (page_id, key);



ALTER TABLE ONLY docs_ai_job
    ADD CONSTRAINT docs_ai_job_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_ai_proposal
    ADD CONSTRAINT docs_ai_proposal_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_ai_session
    ADD CONSTRAINT docs_ai_session_pkey PRIMARY KEY (scope, member_id);



ALTER TABLE ONLY docs_ai_settings
    ADD CONSTRAINT docs_ai_settings_pkey PRIMARY KEY (project_id);



ALTER TABLE ONLY docs_anchor_aliases
    ADD CONSTRAINT docs_anchor_aliases_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_comment_event
    ADD CONSTRAINT docs_comment_event_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_comment
    ADD CONSTRAINT docs_comment_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_comment_read
    ADD CONSTRAINT docs_comment_read_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_comment_thread
    ADD CONSTRAINT docs_comment_thread_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_draft
    ADD CONSTRAINT docs_draft_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_link
    ADD CONSTRAINT docs_link_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_page
    ADD CONSTRAINT docs_page_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_page_seen
    ADD CONSTRAINT docs_page_seen_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_title_aliases
    ADD CONSTRAINT docs_title_aliases_pkey PRIMARY KEY (id);



ALTER TABLE ONLY docs_version
    ADD CONSTRAINT docs_version_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_advice
    ADD CONSTRAINT idea_advice_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_ai_settings
    ADD CONSTRAINT idea_ai_settings_pkey PRIMARY KEY (project_id);



ALTER TABLE ONLY idea_assumption
    ADD CONSTRAINT idea_assumption_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_comment
    ADD CONSTRAINT idea_comment_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_counter
    ADD CONSTRAINT idea_counter_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_digest
    ADD CONSTRAINT idea_digest_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_evidence
    ADD CONSTRAINT idea_evidence_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_log_entry
    ADD CONSTRAINT idea_log_entry_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_ticket
    ADD CONSTRAINT idea_ticket_pkey PRIMARY KEY (id);



ALTER TABLE ONLY idea_vote
    ADD CONSTRAINT idea_vote_pkey PRIMARY KEY (id);



ALTER TABLE ONLY kanban_change
    ADD CONSTRAINT kanban_change_pkey PRIMARY KEY (id);



ALTER TABLE ONLY member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);



ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);



ALTER TABLE ONLY notify_event
    ADD CONSTRAINT notify_event_pkey PRIMARY KEY (id);



ALTER TABLE ONLY notify_follow
    ADD CONSTRAINT notify_follow_pkey PRIMARY KEY (id);



ALTER TABLE ONLY notify_prefs
    ADD CONSTRAINT notify_prefs_pkey PRIMARY KEY (recipient);



ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);



ALTER TABLE ONLY project
    ADD CONSTRAINT project_prefix_key UNIQUE (prefix);



ALTER TABLE ONLY sketch
    ADD CONSTRAINT sketch_pkey PRIMARY KEY (id);



ALTER TABLE ONLY story
    ADD CONSTRAINT story_pkey PRIMARY KEY (ticket_id);



ALTER TABLE ONLY ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (id);



ALTER TABLE ONLY canvas_version
    ADD CONSTRAINT uq_canvas_version UNIQUE (canvas_id, version);



ALTER TABLE ONLY workspace_settings
    ADD CONSTRAINT workspace_settings_pkey PRIMARY KEY (id);



CREATE UNIQUE INDEX ix_ai_account_name ON ai_account USING btree (name);



CREATE INDEX ix_ai_approval_member_id ON ai_approval USING btree (member_id);



CREATE INDEX ix_ai_approval_project_id ON ai_approval USING btree (project_id);



CREATE INDEX ix_ai_approval_ticket_id ON ai_approval USING btree (ticket_id);



CREATE INDEX ix_ai_audit_member_id ON ai_audit USING btree (member_id);



CREATE INDEX ix_ai_audit_project_id ON ai_audit USING btree (project_id);



CREATE INDEX ix_ai_audit_run_id ON ai_audit USING btree (run_id);



CREATE INDEX ix_ai_audit_seq ON ai_audit USING btree (seq);



CREATE INDEX ix_ai_chat_message_chat_id ON ai_chat_message USING btree (chat_id);



CREATE INDEX ix_ai_chat_owner ON ai_chat USING btree (owner);



CREATE INDEX ix_ai_chat_project_id ON ai_chat USING btree (project_id);



CREATE INDEX ix_ai_chat_scope_id ON ai_chat USING btree (scope_id);



CREATE INDEX ix_ai_decision_at ON ai_decision USING btree (at);



CREATE INDEX ix_ai_decision_project_id ON ai_decision USING btree (project_id);



CREATE INDEX ix_ai_decision_story_id ON ai_decision USING btree (story_id);



CREATE INDEX ix_ai_decision_ticket_id ON ai_decision USING btree (ticket_id);



CREATE INDEX ix_ai_digest_project_id ON ai_digest USING btree (project_id);



CREATE INDEX ix_ai_draft_project_id ON ai_draft USING btree (project_id);



CREATE INDEX ix_ai_draft_ticket_id ON ai_draft USING btree (ticket_id);



CREATE INDEX ix_ai_eval_mark_created_at ON ai_eval_mark USING btree (created_at);



CREATE INDEX ix_ai_eval_mark_suite ON ai_eval_mark USING btree (suite);



CREATE INDEX ix_ai_grant_member_id ON ai_grant USING btree (member_id);



CREATE INDEX ix_ai_grant_project_id ON ai_grant USING btree (project_id);



CREATE INDEX ix_ai_grant_role ON ai_grant USING btree (role);



CREATE INDEX ix_ai_grant_ticket_id ON ai_grant USING btree (ticket_id);



CREATE INDEX ix_ai_insight_key ON ai_insight USING btree (key);



CREATE INDEX ix_ai_insight_project_id ON ai_insight USING btree (project_id);



CREATE INDEX ix_ai_knowledge_doc_project_id ON ai_knowledge_doc USING btree (project_id);



CREATE INDEX ix_ai_knowledge_doc_store ON ai_knowledge_doc USING btree (store);



CREATE INDEX ix_ai_lesson_project_id ON ai_lesson USING btree (project_id);



CREATE INDEX ix_ai_lesson_source_ticket_id ON ai_lesson USING btree (source_ticket_id);



CREATE INDEX ix_ai_lesson_state ON ai_lesson USING btree (state);



CREATE INDEX ix_ai_library_item_project_id ON ai_library_item USING btree (project_id);



CREATE INDEX ix_ai_member_account_id ON ai_member USING btree (account_id);



CREATE INDEX ix_ai_member_linked_to ON ai_member USING btree (linked_to);



CREATE INDEX ix_ai_member_project_id ON ai_member USING btree (project_id);



CREATE INDEX ix_ai_memory_note_project_id ON ai_memory_note USING btree (project_id);



CREATE INDEX ix_ai_memory_note_scope ON ai_memory_note USING btree (scope);



CREATE INDEX ix_ai_memory_note_scope_key ON ai_memory_note USING btree (scope_key);



CREATE INDEX ix_ai_notification_created_at ON ai_notification USING btree (created_at);



CREATE INDEX ix_ai_notification_project_id ON ai_notification USING btree (project_id);



CREATE INDEX ix_ai_order_firing_at ON ai_order_firing USING btree (at);



CREATE INDEX ix_ai_order_firing_order_id ON ai_order_firing USING btree (order_id);



CREATE INDEX ix_ai_order_firing_project_id ON ai_order_firing USING btree (project_id);



CREATE INDEX ix_ai_order_firing_target ON ai_order_firing USING btree (target);



CREATE INDEX ix_ai_plugin_name ON ai_plugin USING btree (name);



CREATE INDEX ix_ai_plugin_project_id ON ai_plugin USING btree (project_id);



CREATE INDEX ix_ai_repo_scan_project_id ON ai_repo_scan USING btree (project_id);



CREATE INDEX ix_ai_role_pack_key ON ai_role_pack USING btree (key);



CREATE INDEX ix_ai_role_pack_project_id ON ai_role_pack USING btree (project_id);



CREATE INDEX ix_ai_run_member_id ON ai_run USING btree (member_id);



CREATE INDEX ix_ai_run_project_id ON ai_run USING btree (project_id);



CREATE INDEX ix_ai_run_state ON ai_run USING btree (state);



CREATE INDEX ix_ai_run_ticket_id ON ai_run USING btree (ticket_id);



CREATE INDEX ix_ai_run_token_hash ON ai_run USING btree (token_hash);



CREATE INDEX ix_ai_run_transcript_ended_at ON ai_run_transcript USING btree (ended_at);



CREATE INDEX ix_ai_run_transcript_member_id ON ai_run_transcript USING btree (member_id);



CREATE INDEX ix_ai_run_transcript_project_id ON ai_run_transcript USING btree (project_id);



CREATE INDEX ix_ai_schedule_member_id ON ai_schedule USING btree (member_id);



CREATE INDEX ix_ai_schedule_next_run_at ON ai_schedule USING btree (next_run_at);



CREATE INDEX ix_ai_schedule_project_id ON ai_schedule USING btree (project_id);



CREATE INDEX ix_ai_schedule_run_project_id ON ai_schedule_run USING btree (project_id);



CREATE INDEX ix_ai_schedule_run_schedule_id ON ai_schedule_run USING btree (schedule_id);



CREATE INDEX ix_ai_schedule_run_state ON ai_schedule_run USING btree (state);



CREATE INDEX ix_ai_schedule_run_ticket_id ON ai_schedule_run USING btree (ticket_id);



CREATE INDEX ix_ai_schedule_state ON ai_schedule USING btree (state);



CREATE INDEX ix_ai_schedule_ticket_id ON ai_schedule USING btree (ticket_id);



CREATE INDEX ix_ai_skill_use_member_id ON ai_skill_use USING btree (member_id);



CREATE INDEX ix_ai_skill_use_name ON ai_skill_use USING btree (name);



CREATE INDEX ix_ai_skill_use_plugin ON ai_skill_use USING btree (plugin);



CREATE INDEX ix_ai_skill_use_project_id ON ai_skill_use USING btree (project_id);



CREATE INDEX ix_ai_skill_use_run_id ON ai_skill_use USING btree (run_id);



CREATE INDEX ix_ai_standing_order_project_id ON ai_standing_order USING btree (project_id);



CREATE INDEX ix_ai_standing_order_state ON ai_standing_order USING btree (state);



CREATE INDEX ix_ai_ticket_flag_kind ON ai_ticket_flag USING btree (kind);



CREATE INDEX ix_ai_ticket_flag_project_id ON ai_ticket_flag USING btree (project_id);



CREATE INDEX ix_ai_ticket_flag_ticket_id ON ai_ticket_flag USING btree (ticket_id);



CREATE INDEX ix_ai_ticket_pace_project_id ON ai_ticket_pace USING btree (project_id);



CREATE INDEX ix_ai_ticket_step_run_id ON ai_ticket_step USING btree (run_id);



CREATE INDEX ix_ai_ticket_step_state ON ai_ticket_step USING btree (state);



CREATE INDEX ix_ai_ticket_step_ticket_id ON ai_ticket_step USING btree (ticket_id);



CREATE INDEX ix_ai_ticket_workflow_project_id ON ai_ticket_workflow USING btree (project_id);



CREATE INDEX ix_ai_ticket_workflow_state ON ai_ticket_workflow USING btree (state);



CREATE INDEX ix_ai_usage_created_at ON ai_usage USING btree (created_at);



CREATE INDEX ix_ai_usage_feature ON ai_usage USING btree (feature);



CREATE INDEX ix_ai_usage_project_id ON ai_usage USING btree (project_id);



CREATE INDEX ix_ai_watched_pr_project_id ON ai_watched_pr USING btree (project_id);



CREATE INDEX ix_ai_workflow_template_key ON ai_workflow_template USING btree (key);



CREATE INDEX ix_ai_workflow_template_project_id ON ai_workflow_template USING btree (project_id);



CREATE INDEX ix_ai_worktree_project_id ON ai_worktree USING btree (project_id);



CREATE INDEX ix_ai_worktree_state ON ai_worktree USING btree (state);



CREATE INDEX ix_canvas_comment_thread_id ON canvas_comment USING btree (thread_id);



CREATE INDEX ix_canvas_owner_id ON canvas USING btree (owner_id);



CREATE INDEX ix_canvas_page_id ON canvas USING btree (page_id);



CREATE INDEX ix_canvas_project_id ON canvas USING btree (project_id);



CREATE INDEX ix_canvas_proposal_canvas_id ON canvas_proposal USING btree (canvas_id);



CREATE INDEX ix_canvas_thread_canvas_id ON canvas_thread USING btree (canvas_id);



CREATE INDEX ix_canvas_version_canvas_id ON canvas_version USING btree (canvas_id);



CREATE INDEX ix_diagram_item_id ON diagram USING btree (item_id);



CREATE INDEX ix_diagram_project_id ON diagram USING btree (project_id);



CREATE INDEX ix_diagram_version_diagram_id ON diagram_version USING btree (diagram_id);



CREATE INDEX ix_docs_ai_check_project_id ON docs_ai_check USING btree (project_id);



CREATE INDEX ix_docs_ai_job_kind ON docs_ai_job USING btree (kind);



CREATE INDEX ix_docs_ai_job_member_id ON docs_ai_job USING btree (member_id);



CREATE INDEX ix_docs_ai_job_page_id ON docs_ai_job USING btree (page_id);



CREATE INDEX ix_docs_ai_job_project_id ON docs_ai_job USING btree (project_id);



CREATE INDEX ix_docs_ai_job_state ON docs_ai_job USING btree (state);



CREATE INDEX ix_docs_ai_job_thread_id ON docs_ai_job USING btree (thread_id);



CREATE INDEX ix_docs_ai_proposal_member_id ON docs_ai_proposal USING btree (member_id);



CREATE INDEX ix_docs_ai_proposal_page_id ON docs_ai_proposal USING btree (page_id);



CREATE INDEX ix_docs_ai_proposal_project_id ON docs_ai_proposal USING btree (project_id);



CREATE INDEX ix_docs_ai_proposal_status ON docs_ai_proposal USING btree (status);



CREATE INDEX ix_docs_ai_session_project_id ON docs_ai_session USING btree (project_id);



CREATE INDEX ix_docs_anchor_aliases_page_id ON docs_anchor_aliases USING btree (page_id);



CREATE INDEX ix_docs_comment_event_page_id ON docs_comment_event USING btree (page_id);



CREATE INDEX ix_docs_comment_event_project_id ON docs_comment_event USING btree (project_id);



CREATE INDEX ix_docs_comment_read_thread_id ON docs_comment_read USING btree (thread_id);



CREATE INDEX ix_docs_comment_thread_id ON docs_comment USING btree (thread_id);



CREATE INDEX ix_docs_comment_thread_page_id ON docs_comment_thread USING btree (page_id);



CREATE INDEX ix_docs_draft_page_id ON docs_draft USING btree (page_id);



CREATE INDEX ix_docs_link_source_page_id ON docs_link USING btree (source_page_id);



CREATE INDEX ix_docs_link_target_page_id ON docs_link USING btree (target_page_id);



CREATE INDEX ix_docs_link_target_ticket_id ON docs_link USING btree (target_ticket_id);



CREATE INDEX ix_docs_page_parent_id ON docs_page USING btree (parent_id);



CREATE INDEX ix_docs_page_project_id ON docs_page USING btree (project_id);



CREATE INDEX ix_docs_page_seen_page_id ON docs_page_seen USING btree (page_id);



CREATE INDEX ix_docs_title_aliases_page_id ON docs_title_aliases USING btree (page_id);



CREATE INDEX ix_docs_version_page_id ON docs_version USING btree (page_id);



CREATE INDEX ix_idea_advice_idea_id ON idea_advice USING btree (idea_id);



CREATE INDEX ix_idea_assumption_idea_id ON idea_assumption USING btree (idea_id);



CREATE INDEX ix_idea_comment_idea_id ON idea_comment USING btree (idea_id);



CREATE INDEX ix_idea_digest_project_id ON idea_digest USING btree (project_id);



CREATE INDEX ix_idea_evidence_assumption_id ON idea_evidence USING btree (assumption_id);



CREATE INDEX ix_idea_log_entry_idea_id ON idea_log_entry USING btree (idea_id);



CREATE INDEX ix_idea_ticket_project_id ON idea_ticket USING btree (project_id);



CREATE INDEX ix_idea_ticket_stage ON idea_ticket USING btree (stage);



CREATE INDEX ix_idea_vote_idea_id ON idea_vote USING btree (idea_id);



CREATE INDEX ix_member_project_id ON member USING btree (project_id);



CREATE INDEX ix_notification_created_at ON notification USING btree (created_at);



CREATE INDEX ix_notification_event_id ON notification USING btree (event_id);



CREATE INDEX ix_notification_group_key ON notification USING btree (group_key);



CREATE INDEX ix_notification_kind ON notification USING btree (kind);



CREATE INDEX ix_notification_last_event_id ON notification USING btree (last_event_id);



CREATE INDEX ix_notification_open_needs ON notification USING btree (needs, done_at);



CREATE INDEX ix_notification_project_id ON notification USING btree (project_id);



CREATE INDEX ix_notification_recipient ON notification USING btree (recipient);



CREATE INDEX ix_notification_recipient_open ON notification USING btree (recipient, done_at);



CREATE INDEX ix_notification_target_id ON notification USING btree (target_id);



CREATE INDEX ix_notification_updated_at ON notification USING btree (updated_at);



CREATE INDEX ix_notify_event_created_at ON notify_event USING btree (created_at);



CREATE INDEX ix_notify_event_kind ON notify_event USING btree (kind);



CREATE INDEX ix_notify_event_project_id ON notify_event USING btree (project_id);



CREATE INDEX ix_notify_event_target_id ON notify_event USING btree (target_id);



CREATE INDEX ix_notify_follow_project_id ON notify_follow USING btree (project_id);



CREATE INDEX ix_notify_follow_recipient ON notify_follow USING btree (recipient);



CREATE INDEX ix_notify_follow_scope_id ON notify_follow USING btree (scope_id);



CREATE INDEX ix_sketch_owner_id ON sketch USING btree (owner_id);



CREATE INDEX ix_sketch_project_id ON sketch USING btree (project_id);



CREATE INDEX ix_story_project_id ON story USING btree (project_id);



CREATE INDEX ix_story_state ON story USING btree (state);



CREATE INDEX ix_ticket_assignee ON ticket USING btree (assignee);



CREATE INDEX ix_ticket_from_idea_id ON ticket USING btree (from_idea_id);



CREATE INDEX ix_ticket_parent_id ON ticket USING btree (parent_id);



CREATE INDEX ix_ticket_project_status ON ticket USING btree (project_id, status);



CREATE INDEX ix_ticket_tests_assumption_id ON ticket USING btree (tests_assumption_id);



CREATE UNIQUE INDEX uq_idea_vote_idea_voter ON idea_vote USING btree (idea_id, voter);



CREATE UNIQUE INDEX ux_ai_run_ticket_hold ON ai_run USING btree (ticket_id);



CREATE UNIQUE INDEX ux_ai_schedule_slot ON ai_schedule_run USING btree (schedule_id, slot_at);




