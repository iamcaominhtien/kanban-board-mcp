/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_account` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cli` longtext NOT NULL,
  `folder` longtext NOT NULL,
  `status` longtext NOT NULL,
  `status_detail` longtext DEFAULT NULL,
  `email` longtext DEFAULT NULL,
  `plan` longtext DEFAULT NULL,
  `method` longtext DEFAULT NULL,
  `checked_at` longtext DEFAULT NULL,
  `signed_out_at` longtext DEFAULT NULL,
  `signed_out_how` longtext DEFAULT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_ai_account_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_account` VALUES
('ai_account-0','name 0','cli 0','folder 0','status 0','status_detail 0','email 0','plan 0','method 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','signed_out_how 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_account-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_account-2','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_account_state` (
  `key` varchar(255) NOT NULL,
  `max_parallel` int(11) NOT NULL,
  `move_urgent` tinyint(1) NOT NULL,
  `five_hour_used` float DEFAULT NULL,
  `five_hour_resets_at` longtext DEFAULT NULL,
  `five_hour_status` longtext DEFAULT NULL,
  `seven_day_used` float DEFAULT NULL,
  `seven_day_resets_at` longtext DEFAULT NULL,
  `seven_day_status` longtext DEFAULT NULL,
  `held_until` longtext DEFAULT NULL,
  `held_reason` longtext DEFAULT NULL,
  `updated_at` longtext DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_account_state` VALUES
('ai_account_state-0',0,0,0.25,'2025-03-01T10:00:00.000000+00:00','five_hour_status 0',0.25,'2025-03-01T10:00:00.000000+00:00','seven_day_status 0','held_until 0','held_reason 0','2025-03-01T10:00:00.000000+00:00'),
('ai_account_state-1',7,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
('ai_account_state-2',14,0,3.25,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',3.25,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_approval` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `run_id` longtext DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `action` longtext NOT NULL,
  `summary` longtext NOT NULL,
  `payload` longtext NOT NULL,
  `reason` longtext DEFAULT NULL,
  `risk` longtext NOT NULL,
  `status` longtext NOT NULL,
  `on_behalf_of` longtext DEFAULT NULL,
  `before` longtext NOT NULL,
  `requested_at` longtext NOT NULL,
  `expires_at` longtext DEFAULT NULL,
  `decided_by` longtext DEFAULT NULL,
  `decided_at` longtext DEFAULT NULL,
  `decision_note` longtext DEFAULT NULL,
  `decided_via` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_approval_ticket_id` (`ticket_id`),
  KEY `ix_ai_approval_member_id` (`member_id`),
  KEY `ix_ai_approval_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_approval` VALUES
('ai_approval-0','p-1','member-0','run-0','ticket-0','action 0','summary 0','payload 0','reason 0','risk 0','status 0','on_behalf_of 0','before 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','decided_by 0','2025-03-01T10:00:00.000000+00:00','decision_note 0','decided_via 0'),
('ai_approval-1','p-2','member-1',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL,NULL,NULL),
('ai_approval-2','p-missing','missing-parent','missing-parent','missing-parent','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_assist_settings` (
  `id` int(11) NOT NULL,
  `features` longtext NOT NULL,
  `language` longtext NOT NULL,
  `tone` longtext NOT NULL,
  `style_guide` longtext NOT NULL,
  `monthly_cap` float DEFAULT NULL,
  `per_request_cap` float DEFAULT NULL,
  `over_cap` longtext NOT NULL,
  `data_scope` longtext NOT NULL,
  `excluded_docs` longtext NOT NULL,
  `health` longtext NOT NULL,
  `paused_until` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_assist_settings` VALUES
(1,'features 0','language 0','tone 0','style_guide 0',0.25,0.25,'over_cap 0','data_scope 0','excluded_docs 0','health 0','paused_until 0'),
(2,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL),
(3,'','','','',3.25,3.25,'','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_audit` (
  `id` varchar(255) NOT NULL,
  `seq` int(11) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `member_name` longtext NOT NULL,
  `on_behalf_of` longtext DEFAULT NULL,
  `run_id` varchar(255) DEFAULT NULL,
  `action` longtext NOT NULL,
  `target` longtext DEFAULT NULL,
  `result` longtext NOT NULL,
  `detail` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `reverted_at` longtext DEFAULT NULL,
  `reverted_by` longtext DEFAULT NULL,
  `prev_hash` longtext NOT NULL,
  `hash` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_audit_run_id` (`run_id`),
  KEY `ix_ai_audit_seq` (`seq`),
  KEY `ix_ai_audit_member_id` (`member_id`),
  KEY `ix_ai_audit_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_audit` VALUES
('ai_audit-0',0,'p-1','member-0','member_name 0','on_behalf_of 0','run-0','action 0','target 0','result 0','detail 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','reverted_by 0','prev_hash 0','hash 0'),
('ai_audit-1',7,'p-2',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('ai_audit-2',14,'p-missing','missing-parent','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_chat` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `title` longtext NOT NULL,
  `scope` longtext NOT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `doc_id` longtext DEFAULT NULL,
  `scope_id` varchar(255) DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `include_docs` longtext NOT NULL,
  `cost` float NOT NULL,
  `tokens` int(11) NOT NULL,
  `applied` tinyint(1) NOT NULL,
  `session_id` longtext DEFAULT NULL,
  `summary` longtext NOT NULL,
  `summary_upto` longtext DEFAULT NULL,
  `compactions` int(11) NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_chat_project_id` (`project_id`),
  KEY `ix_ai_chat_owner` (`owner`),
  KEY `ix_ai_chat_scope_id` (`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_chat` VALUES
('ai_chat-0','p-1','owner 0','title 0','scope 0','ticket-0','doc-0','scope-0','member-0','include_docs 0',0.25,0,0,'session-0','summary 0','summary_upto 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_chat-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1.75,7,1,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,7,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_chat-2','p-missing','','','','missing-parent','missing-parent','missing-parent','missing-parent','',3.25,14,0,'missing-parent','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00'),
('c-doc','p-1','owner 0','title 0','doc',NULL,'pg-published','scope-0','member-0','include_docs 0',0.25,0,0,'session-0','summary 0','summary_upto 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('c-project','p-1','owner 0','title 0','project','t-done','pg-draft','scope-0','member-0','include_docs 0',0.25,0,0,'session-0','summary 0','summary_upto 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('c-ticket','p-1','owner 0','title 0','ticket','t-open',NULL,'scope-0','member-0','include_docs 0',0.25,0,0,'session-0','summary 0','summary_upto 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_chat_message` (
  `id` varchar(255) NOT NULL,
  `chat_id` varchar(255) NOT NULL,
  `role` longtext NOT NULL,
  `text` longtext NOT NULL,
  `state` longtext NOT NULL,
  `steps` longtext NOT NULL,
  `context` longtext NOT NULL,
  `actions` longtext NOT NULL,
  `draft_id` longtext DEFAULT NULL,
  `error` longtext NOT NULL,
  `retry_at` longtext DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `model` longtext DEFAULT NULL,
  `cost` float NOT NULL,
  `tokens_in` int(11) NOT NULL,
  `tokens_out` int(11) NOT NULL,
  `metered` tinyint(1) NOT NULL,
  `feedback` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `finished_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_chat_message_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_chat_message` VALUES
('ai_chat_message-0','chat-0','role 0','text 0','state 0','steps 0','context 0','actions 0','draft-0','error 0','2025-03-01T10:00:00.000000+00:00','member-0','model 0',0.25,0,0,0,'feedback 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_chat_message-1','chat-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,1.75,7,7,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL),
('ai_chat_message-2','missing-parent','','','','','','','missing-parent','','2025-05-05T05:05:05.555555+00:00','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',3.25,14,14,0,'','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_config_state` (
  `member_id` varchar(255) NOT NULL,
  `version` int(11) NOT NULL,
  `synced_at` longtext DEFAULT NULL,
  `synced_files` int(11) NOT NULL,
  `ticks` longtext NOT NULL,
  `files` longtext NOT NULL,
  `hooks_ok` longtext NOT NULL,
  `reset_snapshot` longtext DEFAULT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_config_state` VALUES
('ai_config_state-0',0,'2025-03-01T10:00:00.000000+00:00',0,'ticks 0','files 0','hooks_ok 0','reset_snapshot 0','2025-03-01T10:00:00.000000+00:00'),
('ai_config_state-1',7,NULL,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('ai_config_state-2',14,'2025-05-05T05:05:05.555555+00:00',14,'','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_decision` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `story_id` varchar(255) DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `kind` longtext NOT NULL,
  `title` longtext NOT NULL,
  `why` longtext NOT NULL,
  `ref` longtext NOT NULL,
  `state` longtext NOT NULL,
  `overridden_by` longtext DEFAULT NULL,
  `overridden_at` longtext DEFAULT NULL,
  `override_note` longtext DEFAULT NULL,
  `at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_decision_project_id` (`project_id`),
  KEY `ix_ai_decision_ticket_id` (`ticket_id`),
  KEY `ix_ai_decision_at` (`at`),
  KEY `ix_ai_decision_story_id` (`story_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_decision` VALUES
('ai_decision-0','p-1','ticket-0','story-0','member-0','kind 0','title 0','why 0','ref 0','state 0','overridden_by 0','2025-03-01T10:00:00.000000+00:00','override_note 0','2025-03-01T10:00:00.000000+00:00'),
('ai_decision-1','p-2',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00'),
('ai_decision-2','p-missing','missing-parent','missing-parent','missing-parent','','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_digest` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `day` longtext NOT NULL,
  `summary` longtext NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `cost` float NOT NULL,
  `tokens` int(11) NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_digest_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_digest` VALUES
('ai_digest-0','p-1','2025-03-01T10:00:00.000000+00:00','summary 0','member-0',0.25,0,'2025-03-01T10:00:00.000000+00:00'),
('ai_digest-1','p-2','2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,1.75,7,'2025-04-01T00:00:00.000000+00:00'),
('ai_digest-2','p-missing','2025-05-05T05:05:05.555555+00:00','','missing-parent',3.25,14,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_draft` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `owner` longtext NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `member_name` longtext NOT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `doc_id` longtext DEFAULT NULL,
  `chat_message_id` longtext DEFAULT NULL,
  `insight_id` longtext DEFAULT NULL,
  `base` longtext NOT NULL,
  `payload` longtext NOT NULL,
  `raw` longtext NOT NULL,
  `status` longtext NOT NULL,
  `result` longtext NOT NULL,
  `cost` float NOT NULL,
  `tokens` int(11) NOT NULL,
  `created_at` longtext NOT NULL,
  `expires_at` longtext DEFAULT NULL,
  `applied_at` longtext DEFAULT NULL,
  `applied_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_draft_project_id` (`project_id`),
  KEY `ix_ai_draft_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_draft` VALUES
('ai_draft-0','p-1','kind 0','owner 0','member-0','member_name 0','ticket-0','doc-0','chat_message-0','insight-0','base 0','payload 0','raw 0','status 0','result 0',0.25,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','applied_by 0'),
('ai_draft-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1.75,7,'2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL),
('ai_draft-2','p-missing','','','missing-parent','','missing-parent','missing-parent','missing-parent','missing-parent','','','','','',3.25,14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_eval_mark` (
  `id` varchar(255) NOT NULL,
  `suite` varchar(255) NOT NULL,
  `project_id` longtext NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `model` longtext DEFAULT NULL,
  `state` longtext NOT NULL,
  `score` float DEFAULT NULL,
  `details` longtext NOT NULL,
  `runs` longtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `ended_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_eval_mark_suite` (`suite`),
  KEY `ix_ai_eval_mark_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_eval_mark` VALUES
('ai_eval_mark-0','suite 0','p-1','member-0','model 0','state 0',0.25,'details 0','runs 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_eval_mark-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','p-2',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL),
('ai_eval_mark-2','','p-missing','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',3.25,'','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_grant` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `action` longtext DEFAULT NULL,
  `amount` float NOT NULL,
  `day` longtext DEFAULT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `revoked_at` longtext DEFAULT NULL,
  `source_approval_id` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_grant_ticket_id` (`ticket_id`),
  KEY `ix_ai_grant_member_id` (`member_id`),
  KEY `ix_ai_grant_project_id` (`project_id`),
  KEY `ix_ai_grant_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_grant` VALUES
('ai_grant-0','p-1','kind 0','member-0','role 0','ticket-0','action 0',0.25,'2025-03-01T10:00:00.000000+00:00','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','source_approval-0'),
('ai_grant-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,1.75,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('ai_grant-2','p-missing','','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',3.25,'2025-05-05T05:05:05.555555+00:00','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','missing-parent');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_insight` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `key` varchar(255) NOT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `title` longtext NOT NULL,
  `detail` longtext NOT NULL,
  `data` longtext NOT NULL,
  `score` float NOT NULL,
  `state` longtext NOT NULL,
  `snoozed_until` longtext DEFAULT NULL,
  `seen` tinyint(1) NOT NULL,
  `draft_id` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_insight_key` (`key`),
  KEY `ix_ai_insight_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_insight` VALUES
('ai_insight-0','p-1','kind 0','key 0','ticket-0','title 0','detail 0','data 0',0.25,'state 0','snoozed_until 0',0,'draft-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_insight-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1.75,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,1,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_insight-2','p-missing','','','missing-parent','','','',3.25,'','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,'missing-parent','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_knowledge_doc` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `store` varchar(255) NOT NULL,
  `title` longtext NOT NULL,
  `kind` longtext NOT NULL,
  `text` longtext NOT NULL,
  `summary` longtext DEFAULT NULL,
  `keywords` longtext NOT NULL,
  `answers` longtext NOT NULL,
  `described_by` longtext DEFAULT NULL,
  `source_name` longtext DEFAULT NULL,
  `upload_url` longtext DEFAULT NULL,
  `private` tinyint(1) NOT NULL,
  `tokens` int(11) NOT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `last_read_at` longtext DEFAULT NULL,
  `deleted_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_knowledge_doc_project_id` (`project_id`),
  KEY `ix_ai_knowledge_doc_store` (`store`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_knowledge_doc` VALUES
('ai_knowledge_doc-0','p-1','store 0','title 0','kind 0','text 0','summary 0','keywords 0','answers 0','described_by 0','source_name 0','upload_url 0',0,0,'created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_knowledge_doc-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,1,7,NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('ai_knowledge_doc-2','p-missing','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_lesson` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `text` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `source_ticket_id` varchar(255) DEFAULT NULL,
  `source_run_id` longtext DEFAULT NULL,
  `proposed_by` longtext DEFAULT NULL,
  `kept_by` longtext DEFAULT NULL,
  `uses` int(11) NOT NULL,
  `last_used_at` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_lesson_project_id` (`project_id`),
  KEY `ix_ai_lesson_source_ticket_id` (`source_ticket_id`),
  KEY `ix_ai_lesson_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_lesson` VALUES
('ai_lesson-0','p-1','text 0','state 0','source_ticket-0','source_run-0','proposed_by 0','kept_by 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_lesson-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,7,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_lesson-2','p-missing','','','missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_library_item` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `type` longtext NOT NULL,
  `name` longtext NOT NULL,
  `description` longtext NOT NULL,
  `content` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `history` longtext NOT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_library_item_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_library_item` VALUES
('ai_library_item-0','p-1','type 0','name 0','description 0','content 0',0,'history 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_library_item-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_library_item-2','p-missing','','','','',14,'','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_member` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `linked_to` varchar(255) DEFAULT NULL,
  `provider` longtext NOT NULL,
  `connection` longtext NOT NULL,
  `description` longtext NOT NULL,
  `glyph` longtext NOT NULL,
  `cli_path` longtext DEFAULT NULL,
  `working_dir` longtext DEFAULT NULL,
  `base_url` longtext DEFAULT NULL,
  `model` longtext DEFAULT NULL,
  `key_enc` longtext DEFAULT NULL,
  `key_last4` longtext DEFAULT NULL,
  `persona` longtext NOT NULL,
  `resource_access` longtext NOT NULL,
  `max_parallel` int(11) NOT NULL,
  `daily_budget` float DEFAULT NULL,
  `monthly_cap` float DEFAULT NULL,
  `max_runs_per_day` int(11) DEFAULT NULL,
  `template` longtext NOT NULL,
  `ceiling` longtext NOT NULL,
  `permissions` longtext NOT NULL,
  `scope` longtext NOT NULL,
  `config` longtext NOT NULL,
  `paused` tinyint(1) NOT NULL,
  `paused_at` longtext DEFAULT NULL,
  `paused_reason` longtext DEFAULT NULL,
  `health` longtext NOT NULL,
  `health_detail` longtext DEFAULT NULL,
  `checked_at` longtext DEFAULT NULL,
  `cli_version` longtext DEFAULT NULL,
  `account` longtext DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `last_call_at` longtext DEFAULT NULL,
  `retry_at` longtext DEFAULT NULL,
  `remove_after_run` tinyint(1) NOT NULL,
  `safe_mode` tinyint(1) NOT NULL,
  `allow_external` tinyint(1) NOT NULL,
  `tokens_per_day` int(11) DEFAULT NULL,
  `cap_per_run` float DEFAULT NULL,
  `warn_at` longtext NOT NULL,
  `key_rotated_at` longtext DEFAULT NULL,
  `mcp_last_used_at` longtext DEFAULT NULL,
  `token_revoked_at` longtext DEFAULT NULL,
  `token_revoked_by` longtext DEFAULT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_member_linked_to` (`linked_to`),
  KEY `ix_ai_member_project_id` (`project_id`),
  KEY `ix_ai_member_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_member` VALUES
('ai_member-0','p-1','linked_to 0','provider 0','connection 0','description 0','glyph 0','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_member-1','p-2',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_member-2','p-missing','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','',14,3.25,3.25,14,'','','','','',0,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00',0,0,0,14,3.25,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00'),
('m-anthropic','p-2','linked_to 0','anthropic','connection 0','description 0','hex','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-antigravity','p-2','linked_to 0','antigravity','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-claude-code','p-2','linked_to 0','claude-code','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-custom','p-2','linked_to 0','custom','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-gemini','p-2','linked_to 0','gemini','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-human-with-profile','p-2','linked_to 0','openai','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-mcp-client','p-2','linked_to 0','mcp-client','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-no-member-row','p-2','linked_to 0','gemini','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-openai','p-2','linked_to 0','openai','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('m-unknown','p-2','linked_to 0','unknown','connection 0','description 0','spark','cli_path 0','working_dir 0','base_url 0','model 0','key_enc 0','key_last4 0','persona 0','resource_access 0',0,0.25,0.25,0,'template 0','ceiling 0','permissions 0','scope 0','config 0',0,'2025-03-01T10:00:00.000000+00:00','paused_reason 0','health 0','health_detail 0','2025-03-01T10:00:00.000000+00:00','cli_version 0','account 0','account-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','token_revoked_by 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_memory_note` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `scope` varchar(255) NOT NULL,
  `scope_key` varchar(255) NOT NULL,
  `text` longtext NOT NULL,
  `kind` longtext NOT NULL,
  `written_by` longtext DEFAULT NULL,
  `source_run_id` longtext DEFAULT NULL,
  `source_ticket_id` longtext DEFAULT NULL,
  `uses` int(11) NOT NULL,
  `last_used_at` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_memory_note_project_id` (`project_id`),
  KEY `ix_ai_memory_note_scope` (`scope`),
  KEY `ix_ai_memory_note_scope_key` (`scope_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_memory_note` VALUES
('ai_memory_note-0','p-1','scope 0','scope_key 0','text 0','kind 0','written_by 0','source_run-0','source_ticket-0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_memory_note-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,7,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_memory_note-2','p-missing','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent',14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_notification` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `event` longtext NOT NULL,
  `title` longtext NOT NULL,
  `body` longtext NOT NULL,
  `ref_kind` longtext DEFAULT NULL,
  `ref_id` longtext DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `people` longtext NOT NULL,
  `urgent` tinyint(1) NOT NULL,
  `inapp` tinyint(1) NOT NULL,
  `desktop` tinyint(1) NOT NULL,
  `data` longtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_notification_created_at` (`created_at`),
  KEY `ix_ai_notification_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_notification` VALUES
('ai_notification-0','p-1','event 0','title 0','body 0','ref_kind 0','ref-0','member-0','people 0',0,0,0,'data 0','2025-03-01T10:00:00.000000+00:00'),
('ai_notification-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('ai_notification-2','p-missing','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent','',0,0,0,'','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_order_firing` (
  `id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `at` varchar(255) NOT NULL,
  `target` varchar(255) DEFAULT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `trigger` longtext NOT NULL,
  `action` longtext NOT NULL,
  `would` tinyint(1) NOT NULL,
  `result` longtext DEFAULT NULL,
  `undo` longtext DEFAULT NULL,
  `undone_at` longtext DEFAULT NULL,
  `undone_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_order_firing_at` (`at`),
  KEY `ix_ai_order_firing_order_id` (`order_id`),
  KEY `ix_ai_order_firing_target` (`target`),
  KEY `ix_ai_order_firing_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_order_firing` VALUES
('ai_order_firing-0','order-0','p-1','2025-03-01T10:00:00.000000+00:00','target 0','ticket-0','trigger 0','action 0',0,'result 0','undo 0','2025-03-01T10:00:00.000000+00:00','undone_by 0'),
('ai_order_firing-1','order-1','p-2','2025-04-01T00:00:00.000000+00:00',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,NULL,NULL,NULL),
('ai_order_firing-2','missing-parent','p-missing','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','','',0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_plugin` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `source_kind` longtext NOT NULL,
  `source` longtext NOT NULL,
  `ref` longtext DEFAULT NULL,
  `plugin` longtext DEFAULT NULL,
  `skills_wanted` longtext NOT NULL,
  `commit` longtext DEFAULT NULL,
  `version` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `path` longtext DEFAULT NULL,
  `skills` longtext NOT NULL,
  `hooks` int(11) NOT NULL,
  `mcp` int(11) NOT NULL,
  `size_bytes` int(11) NOT NULL,
  `pinned` tinyint(1) NOT NULL,
  `default_on` tinyint(1) NOT NULL,
  `roles` longtext NOT NULL,
  `members` longtext NOT NULL,
  `previous` longtext DEFAULT NULL,
  `installed_by` longtext DEFAULT NULL,
  `installed_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_plugin_name` (`name`),
  KEY `ix_ai_plugin_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_plugin` VALUES
('ai_plugin-0','p-1','name 0','source_kind 0','source 0','ref 0','plugin 0','skills_wanted 0','commit 0','version 0','description 0','path 0','skills 0',0,0,0,0,0,'roles 0','members 0','previous 0','installed_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_plugin-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,7,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_plugin-2','p-missing','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',14,14,14,0,0,'','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_project_knowledge` (
  `project_id` varchar(255) NOT NULL,
  `instructions` longtext NOT NULL,
  `history` longtext NOT NULL,
  `updated_at` longtext DEFAULT NULL,
  `updated_by` longtext DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_project_knowledge` VALUES
('ai_project_knowledge-0','instructions 0','history 0','2025-03-01T10:00:00.000000+00:00','updated_by 0'),
('ai_project_knowledge-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL),
('ai_project_knowledge-2','','','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_project_settings` (
  `project_id` varchar(255) NOT NULL,
  `board_ai_id` longtext DEFAULT NULL,
  `ai_enabled` tinyint(1) NOT NULL,
  `paused_all` tinyint(1) NOT NULL,
  `paused_at` longtext DEFAULT NULL,
  `paused_by` longtext DEFAULT NULL,
  `paused_reason` longtext DEFAULT NULL,
  `safe_mode` tinyint(1) NOT NULL,
  `board_daily_cap` float DEFAULT NULL,
  `board_monthly_budget` float DEFAULT NULL,
  `max_chain_depth` int(11) NOT NULL,
  `runs_per_ticket_per_day` int(11) NOT NULL,
  `approval_expiry_hours` int(11) NOT NULL,
  `board_tokens_per_day` int(11) DEFAULT NULL,
  `board_max_parallel` int(11) NOT NULL,
  `run_memory_limit_mb` int(11) NOT NULL,
  `board_runs_per_day` int(11) DEFAULT NULL,
  `board_at_cap` longtext NOT NULL,
  `approval_on_expiry` longtext NOT NULL,
  `approvers` longtext NOT NULL,
  `delegates` longtext NOT NULL,
  `audit_retention_days` int(11) DEFAULT NULL,
  `run_retention_days` int(11) DEFAULT NULL,
  `loop_cooldown_s` int(11) NOT NULL,
  `no_repeat_chain` tinyint(1) NOT NULL,
  `docs_edits_ask` tinyint(1) NOT NULL,
  `autopilot` longtext NOT NULL,
  `allowed_domains` longtext NOT NULL,
  `alert_state` longtext NOT NULL,
  `checklist` longtext NOT NULL,
  `key_reminder_days` int(11) NOT NULL,
  `auto_trip` longtext NOT NULL,
  `paused_cancelled` int(11) NOT NULL,
  `paused_held` int(11) NOT NULL,
  `paused_tokens_revoked` tinyint(1) NOT NULL,
  `paused_let_finish` tinyint(1) NOT NULL,
  `paused_safe_before` tinyint(1) NOT NULL,
  `team_dismissed` longtext NOT NULL,
  `ops` longtext NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_project_settings` VALUES
('ai_project_settings-0','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,0,0,0,0,0,0,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('ai_project_settings-1',NULL,1,1,NULL,NULL,NULL,1,NULL,NULL,7,7,7,NULL,7,7,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,7,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,1,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('ai_project_settings-2','missing-parent',0,0,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,3.25,3.25,14,14,14,14,14,14,14,'','','','',14,14,14,0,0,'','','','',14,'',14,14,0,0,0,'',''),
('p-1','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,6,0,0,0,0,60,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-2','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,9,0,0,0,0,NULL,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-bad-json','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,6,0,0,0,0,100,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-empty','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,15,0,0,0,0,60,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-last','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,0,0,0,0,0,0,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-list','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,0,0,0,0,0,0,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0'),
('p-null','board_ai-0',0,0,'2025-03-01T10:00:00.000000+00:00','paused_by 0','paused_reason 0',0,0.25,0.25,0,0,0,0,0,0,0,'board_at_cap 0','approval_on_expiry 0','approvers 0','delegates 0',0,0,0,0,0,'autopilot 0','allowed_domains 0','alert_state 0','checklist 0',0,'auto_trip 0',0,0,0,0,0,'team_dismissed 0','ops 0');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_repo_scan` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `folder` longtext NOT NULL,
  `found` longtext NOT NULL,
  `suggested` longtext NOT NULL,
  `trial` longtext NOT NULL,
  `job` longtext NOT NULL,
  `proposal` longtext NOT NULL,
  `applied_at` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_repo_scan_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_repo_scan` VALUES
('ai_repo_scan-0','p-1','folder 0','found 0','suggested 0','trial 0','job 0','proposal 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_repo_scan-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('ai_repo_scan-2','p-missing','','','','','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_role_pack` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `name` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `body` longtext NOT NULL,
  `history` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `updated_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_role_pack_key` (`key`),
  KEY `ix_ai_role_pack_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_role_pack` VALUES
('ai_role_pack-0','p-1','key 0','name 0',0,'body 0','history 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','updated_by 0'),
('ai_role_pack-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00',NULL),
('ai_role_pack-2','p-missing','','',14,'','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_run` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `number` int(11) NOT NULL,
  `mode` longtext NOT NULL,
  `trigger` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `started_by` longtext NOT NULL,
  `instruction` longtext NOT NULL,
  `source_comment_id` longtext DEFAULT NULL,
  `reply_comment_id` longtext DEFAULT NULL,
  `include_context` tinyint(1) NOT NULL,
  `chain` longtext NOT NULL,
  `queued_at` longtext NOT NULL,
  `started_at` longtext DEFAULT NULL,
  `ended_at` longtext DEFAULT NULL,
  `last_output_at` longtext DEFAULT NULL,
  `ended_reason` longtext DEFAULT NULL,
  `ended_by` longtext DEFAULT NULL,
  `exit_code` int(11) DEFAULT NULL,
  `summary` longtext DEFAULT NULL,
  `report` longtext NOT NULL,
  `question` longtext DEFAULT NULL,
  `answer` longtext DEFAULT NULL,
  `session_id` longtext DEFAULT NULL,
  `steps` longtext NOT NULL,
  `files` longtext NOT NULL,
  `tokens_in` int(11) NOT NULL,
  `tokens_out` int(11) NOT NULL,
  `tokens_cached` int(11) DEFAULT NULL,
  `cost_usd` float NOT NULL,
  `metered` tinyint(1) NOT NULL,
  `context_used` int(11) DEFAULT NULL,
  `context_window` int(11) DEFAULT NULL,
  `report_back` longtext DEFAULT NULL,
  `status_before` longtext DEFAULT NULL,
  `status_changes` longtext NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `model` longtext DEFAULT NULL,
  `paused` tinyint(1) NOT NULL,
  `paused_at` longtext DEFAULT NULL,
  `behind_run_id` longtext DEFAULT NULL,
  `queue_after_current` tinyint(1) NOT NULL,
  `limit_min` int(11) DEFAULT NULL,
  `replaces_comment_id` longtext DEFAULT NULL,
  `feedback` longtext DEFAULT NULL,
  `stop_code` longtext DEFAULT NULL,
  `blocked_move` longtext DEFAULT NULL,
  `context_notes` longtext NOT NULL,
  `memory_used` longtext DEFAULT NULL,
  `started_via` longtext DEFAULT NULL,
  `peak_rss_mb` float DEFAULT NULL,
  `last_rss_mb` float DEFAULT NULL,
  `restarts` longtext NOT NULL,
  `diagnosis` longtext DEFAULT NULL,
  `retry_at` longtext DEFAULT NULL,
  `retries` longtext NOT NULL,
  `account_id` longtext DEFAULT NULL,
  `model_override` longtext DEFAULT NULL,
  `effort_override` longtext DEFAULT NULL,
  `details_removed_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ux_ai_run_ticket_hold` (`ticket_id`),
  KEY `ix_ai_run_project_id` (`project_id`),
  KEY `ix_ai_run_state` (`state`),
  KEY `ix_ai_run_ticket_id` (`ticket_id`),
  KEY `ix_ai_run_token_hash` (`token_hash`),
  KEY `ix_ai_run_member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_run` VALUES
('ai_run-0','p-1','ticket-0','member-0',0,'mode 0','trigger 0','state 0','started_by 0','instruction 0','source_comment-0','reply_comment-0',0,'chain 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','ended_reason 0','ended_by 0',0,'summary 0','report 0','question 0','answer 0','session-0','steps 0','files 0',0,0,0,0.25,0,0,0,'report_back 0','status_before 0','status_changes 0',0,'token_hash 0','model 0',0,'2025-03-01T10:00:00.000000+00:00','behind_run-0',0,0,'replaces_comment-0','feedback 0','stop_code 0','blocked_move 0','context_notes 0','memory_used 0','started_via 0',0.25,0.25,'restarts 0','diagnosis 0','2025-03-01T10:00:00.000000+00:00','retries 0','account-0','model_override 0','effort_override 0','2025-03-01T10:00:00.000000+00:00'),
('ai_run-1','p-2','ticket-1','member-1',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,NULL,1.75,1,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,1,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL),
('ai_run-2','p-missing','missing-parent','missing-parent',14,'','','','','','missing-parent','missing-parent',0,'','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','','',14,14,14,3.25,0,14,14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,'2025-05-05T05:05:05.555555+00:00','missing-parent',0,14,'missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',3.25,3.25,'','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_run_transcript` (
  `run_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `path` longtext NOT NULL,
  `bytes` int(11) NOT NULL,
  `events` int(11) NOT NULL,
  `pinned` tinyint(1) NOT NULL,
  `pinned_by` longtext DEFAULT NULL,
  `started_at` longtext NOT NULL,
  `ended_at` varchar(255) DEFAULT NULL,
  `deleted_at` longtext DEFAULT NULL,
  PRIMARY KEY (`run_id`),
  KEY `ix_ai_run_transcript_member_id` (`member_id`),
  KEY `ix_ai_run_transcript_project_id` (`project_id`),
  KEY `ix_ai_run_transcript_ended_at` (`ended_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_run_transcript` VALUES
('ai_run_transcript-0','p-1','member-0','path 0',0,0,0,'pinned_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_run_transcript-1','p-2',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,1,NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('ai_run_transcript-2','p-missing','missing-parent','',14,14,0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_schedule` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `backup_member_id` longtext DEFAULT NULL,
  `created_by` longtext NOT NULL,
  `kind` longtext NOT NULL,
  `run_at` longtext DEFAULT NULL,
  `days` longtext NOT NULL,
  `time` longtext NOT NULL,
  `tz` longtext NOT NULL,
  `ends` longtext NOT NULL,
  `ends_after` int(11) DEFAULT NULL,
  `ends_on` longtext DEFAULT NULL,
  `window_end` longtext DEFAULT NULL,
  `checks` longtext NOT NULL,
  `review` longtext NOT NULL,
  `limits` longtext NOT NULL,
  `catch_up` longtext NOT NULL,
  `catch_up_hours` float NOT NULL,
  `notify` longtext NOT NULL,
  `notify_people` longtext NOT NULL,
  `instruction` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `paused_reason` longtext DEFAULT NULL,
  `failures_in_row` int(11) NOT NULL,
  `runs_count` int(11) NOT NULL,
  `next_run_at` varchar(255) DEFAULT NULL,
  `ticket_seen_at` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_schedule_member_id` (`member_id`),
  KEY `ix_ai_schedule_state` (`state`),
  KEY `ix_ai_schedule_project_id` (`project_id`),
  KEY `ix_ai_schedule_next_run_at` (`next_run_at`),
  KEY `ix_ai_schedule_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_schedule` VALUES
('ai_schedule-0','p-1','ticket-0','member-0','backup_member-0','created_by 0','kind 0','2025-03-01T10:00:00.000000+00:00','days 0','time 0','tz 0','ends 0',0,'ends_on 0','window_end 0','checks 0','review 0','limits 0','catch_up 0',0.25,'notify 0','notify_people 0','instruction 0','state 0','paused_reason 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_schedule-1','p-2','ticket-1','member-1',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1.75,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,7,7,NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_schedule-2','p-missing','missing-parent','missing-parent','missing-parent','','','2025-05-05T05:05:05.555555+00:00','','','','',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','',3.25,'','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_schedule_run` (
  `id` varchar(255) NOT NULL,
  `schedule_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `slot_at` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `catch_up` tinyint(1) NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `run_ids` longtext NOT NULL,
  `attempts` int(11) NOT NULL,
  `fix_round` int(11) NOT NULL,
  `results` longtext NOT NULL,
  `review` longtext NOT NULL,
  `note` longtext DEFAULT NULL,
  `started_at` longtext DEFAULT NULL,
  `ended_at` longtext DEFAULT NULL,
  `duration_s` int(11) NOT NULL,
  `cost_usd` float NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_ai_schedule_slot` (`schedule_id`,`slot_at`),
  KEY `ix_ai_schedule_run_ticket_id` (`ticket_id`),
  KEY `ix_ai_schedule_run_state` (`state`),
  KEY `ix_ai_schedule_run_schedule_id` (`schedule_id`),
  KEY `ix_ai_schedule_run_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_schedule_run` VALUES
('ai_schedule_run-0','schedule-0','p-1','ticket-0','2025-03-01T10:00:00.000000+00:00','state 0',0,'member-0','run_ids 0',0,0,'results 0','review 0','note 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0.25,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_schedule_run-1','schedule-1','p-2','ticket-1','2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,7,1.75,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_schedule_run-2','missing-parent','p-missing','missing-parent','2025-05-05T05:05:05.555555+00:00','',0,'missing-parent','',14,14,'','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00',14,3.25,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_skill_use` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `run_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `kind` longtext NOT NULL,
  `name` varchar(255) NOT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_skill_use_member_id` (`member_id`),
  KEY `ix_ai_skill_use_name` (`name`),
  KEY `ix_ai_skill_use_run_id` (`run_id`),
  KEY `ix_ai_skill_use_plugin` (`plugin`),
  KEY `ix_ai_skill_use_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_skill_use` VALUES
(1,'run-0','p-1','member-0','kind 0','name 0','plugin 0','2025-03-01T10:00:00.000000+00:00'),
(2,'run-1','p-2',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
(3,'missing-parent','p-missing','missing-parent','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_standing_order` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `name` longtext NOT NULL,
  `sentence` longtext NOT NULL,
  `rule` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `trial_days` int(11) NOT NULL,
  `trial_started_at` longtext DEFAULT NULL,
  `trial_fired_at` longtext DEFAULT NULL,
  `fired` int(11) NOT NULL,
  `would_have` int(11) NOT NULL,
  `last_fired_at` longtext DEFAULT NULL,
  `last_summary` longtext DEFAULT NULL,
  `template` longtext DEFAULT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_standing_order_project_id` (`project_id`),
  KEY `ix_ai_standing_order_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_standing_order` VALUES
('ai_standing_order-0','p-1','name 0','sentence 0','rule 0','state 0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',0,0,'2025-03-01T10:00:00.000000+00:00','last_summary 0','template 0','created_by 0','2025-03-01T10:00:00.000000+00:00'),
('ai_standing_order-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,NULL,NULL,7,7,NULL,NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00'),
('ai_standing_order-2','p-missing','','','','',14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00',14,14,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_ticket_flag` (
  `id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `resolved_at` longtext DEFAULT NULL,
  `resolved_by` longtext DEFAULT NULL,
  `resolution` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_ticket_flag_project_id` (`project_id`),
  KEY `ix_ai_ticket_flag_kind` (`kind`),
  KEY `ix_ai_ticket_flag_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_ticket_flag` VALUES
('ai_ticket_flag-0','ticket-0','p-1','kind 0','data 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','resolved_by 0','resolution 0'),
('ai_ticket_flag-1','ticket-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL),
('ai_ticket_flag-2','missing-parent','p-missing','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_ticket_pace` (
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `pace` longtext NOT NULL,
  `set_by` longtext DEFAULT NULL,
  `set_at` longtext NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ix_ai_ticket_pace_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_ticket_pace` VALUES
('ai_ticket_pace-0','p-1','pace 0','set_by 0','2025-03-01T10:00:00.000000+00:00'),
('ai_ticket_pace-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('ai_ticket_pace-2','p-missing','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_ticket_step` (
  `id` varchar(255) NOT NULL,
  `ticket_id` varchar(255) NOT NULL,
  `seq` int(11) NOT NULL,
  `idx` int(11) NOT NULL,
  `key` longtext NOT NULL,
  `label` longtext NOT NULL,
  `kind` longtext NOT NULL,
  `role` longtext DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  `attempt` int(11) NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `run_id` varchar(255) DEFAULT NULL,
  `note_in` longtext DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `outcome` longtext DEFAULT NULL,
  `result` longtext DEFAULT NULL,
  `started_at` longtext DEFAULT NULL,
  `ended_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_ticket_step_run_id` (`run_id`),
  KEY `ix_ai_ticket_step_state` (`state`),
  KEY `ix_ai_ticket_step_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_ticket_step` VALUES
('ai_ticket_step-0','ticket-0',0,0,'key 0','label 0','kind 0','role 0','state 0',0,'member-0','run-0','note_in 0','note 0','outcome 0','result 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_ticket_step-1','ticket-1',7,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
('ai_ticket_step-2','missing-parent',14,14,'','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',14,'missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_ticket_workflow` (
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `template_key` longtext NOT NULL,
  `template_name` longtext NOT NULL,
  `template_version` int(11) NOT NULL,
  `steps` longtext NOT NULL,
  `state` varchar(255) NOT NULL,
  `stop_reason` longtext DEFAULT NULL,
  `stop_detail` longtext DEFAULT NULL,
  `review_depth` longtext DEFAULT NULL,
  `depth_by` longtext DEFAULT NULL,
  `depth_note` longtext DEFAULT NULL,
  `pace` longtext DEFAULT NULL,
  `rounds` longtext NOT NULL,
  `objections` longtext NOT NULL,
  `rulings` longtext NOT NULL,
  `arbitration_run_id` longtext DEFAULT NULL,
  `reviewer_id` longtext DEFAULT NULL,
  `seq_base` int(11) NOT NULL,
  `attached_by` longtext DEFAULT NULL,
  `meta` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ix_ai_ticket_workflow_state` (`state`),
  KEY `ix_ai_ticket_workflow_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_ticket_workflow` VALUES
('ai_ticket_workflow-0','p-1','template_key 0','template_name 0',0,'steps 0','state 0','stop_reason 0','stop_detail 0','review_depth 0','depth_by 0','depth_note 0','pace 0','rounds 0','objections 0','rulings 0','arbitration_run-0','reviewer-0',0,'attached_by 0','meta 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_ticket_workflow-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,7,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ai_ticket_workflow-2','p-missing','','',14,'','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','missing-parent','missing-parent',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_usage` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `feature` varchar(255) NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `person` longtext DEFAULT NULL,
  `cost` float NOT NULL,
  `tokens_in` int(11) NOT NULL,
  `tokens_out` int(11) NOT NULL,
  `metered` tinyint(1) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_usage_project_id` (`project_id`),
  KEY `ix_ai_usage_created_at` (`created_at`),
  KEY `ix_ai_usage_feature` (`feature`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_usage` VALUES
('ai_usage-0','p-1','feature 0','member-0','person 0',0.25,0,0,0,'2025-03-01T10:00:00.000000+00:00'),
('ai_usage-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,1.75,7,7,1,'2025-04-01T00:00:00.000000+00:00'),
('ai_usage-2','p-missing','','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',3.25,14,14,0,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_watched_pr` (
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `number` int(11) NOT NULL,
  `url` longtext DEFAULT NULL,
  `branch` longtext NOT NULL,
  `repo` longtext NOT NULL,
  `state` longtext NOT NULL,
  `ci` longtext DEFAULT NULL,
  `red` longtext DEFAULT NULL,
  `seen_comments` longtext NOT NULL,
  `pending_comments` longtext NOT NULL,
  `checked_at` longtext DEFAULT NULL,
  `last_error` longtext DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ix_ai_watched_pr_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_watched_pr` VALUES
('ai_watched_pr-0','p-1',0,'url 0','branch 0','repo 0','state 0','ci 0','red 0','seen_comments 0','pending_comments 0','2025-03-01T10:00:00.000000+00:00','last_error 0'),
('ai_watched_pr-1','p-2',7,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL),
('ai_watched_pr-2','p-missing',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_workflow_template` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `name` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `body` longtext NOT NULL,
  `history` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `updated_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ai_workflow_template_project_id` (`project_id`),
  KEY `ix_ai_workflow_template_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_workflow_template` VALUES
('ai_workflow_template-0','p-1','key 0','name 0',0,'body 0','history 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','updated_by 0'),
('ai_workflow_template-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00',NULL),
('ai_workflow_template-2','p-missing','','',14,'','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_workspace_defaults` (
  `id` int(11) NOT NULL,
  `template` longtext NOT NULL,
  `ceiling` longtext NOT NULL,
  `delete_mode` longtext NOT NULL,
  `daily_budget` float DEFAULT NULL,
  `monthly_cap` float DEFAULT NULL,
  `updated_by` longtext DEFAULT NULL,
  `updated_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_workspace_defaults` VALUES
(1,'template 0','ceiling 0','delete_mode 0',0.25,0.25,'updated_by 0','2025-03-01T10:00:00.000000+00:00'),
(2,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL),
(3,'','','',3.25,3.25,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_worktree` (
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `repo` longtext NOT NULL,
  `path` longtext NOT NULL,
  `branch` longtext NOT NULL,
  `base` longtext NOT NULL,
  `port` int(11) DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  `handover` longtext DEFAULT NULL,
  `pr_url` longtext DEFAULT NULL,
  `pr_number` int(11) DEFAULT NULL,
  `conflict_files` longtext NOT NULL,
  `prepared_at` longtext DEFAULT NULL,
  `prepare_s` int(11) DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `last_used_at` longtext DEFAULT NULL,
  `merged_at` longtext DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ix_ai_worktree_state` (`state`),
  KEY `ix_ai_worktree_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_worktree` VALUES
('ai_worktree-0','p-1','repo 0','path 0','branch 0','base 0',0,'state 0','handover 0','pr_url 0',0,'conflict_files 0','2025-03-01T10:00:00.000000+00:00',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ai_worktree-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('ai_worktree-2','p-missing','','','','',14,'','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'','2025-05-05T05:05:05.555555+00:00',14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `alembic_version` VALUES
('f1c3e5a7b9d2');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `canvas` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `owner_kind` longtext NOT NULL,
  `owner_id` varchar(255) NOT NULL,
  `page_id` varchar(255) DEFAULT NULL,
  `title` longtext NOT NULL,
  `rev` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  `board_count` int(11) NOT NULL,
  `total_bytes` int(11) NOT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_by` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `deleted_at` longtext DEFAULT NULL,
  `deleted_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_canvas_page_id` (`page_id`),
  KEY `ix_canvas_owner_id` (`owner_id`),
  KEY `ix_canvas_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `canvas` VALUES
('canvas-0','p-1','owner_kind 0','owner-0','page-0','title 0',0,0,0,0,'created_by 0','2025-03-01T10:00:00.000000+00:00','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','deleted_by 0'),
('canvas-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','owner-1',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,7,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('canvas-2','p-missing','','missing-parent','missing-parent','',14,14,14,14,'','2025-05-05T05:05:05.555555+00:00','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `canvas_comment` (
  `id` varchar(255) NOT NULL,
  `thread_id` varchar(255) NOT NULL,
  `author` longtext NOT NULL,
  `body` longtext NOT NULL,
  `mentions` longtext NOT NULL,
  `ai` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `edited_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_canvas_comment_thread_id` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `canvas_comment` VALUES
('canvas_comment-0','thread-0','author 0','body 0','mentions 0','ai 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('canvas_comment-1','thread-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00',NULL),
('canvas_comment-2','missing-parent','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `canvas_proposal` (
  `id` varchar(255) NOT NULL,
  `canvas_id` varchar(255) NOT NULL,
  `author` longtext NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `job_id` longtext DEFAULT NULL,
  `request` longtext NOT NULL,
  `note` longtext NOT NULL,
  `status` longtext NOT NULL,
  `changes` longtext NOT NULL,
  `version` int(11) DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `decided_by` longtext DEFAULT NULL,
  `decided_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_canvas_proposal_canvas_id` (`canvas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `canvas_proposal` VALUES
('canvas_proposal-0','canvas-0','author 0','member-0','job-0','request 0','note 0','status 0','changes 0',0,'2025-03-01T10:00:00.000000+00:00','decided_by 0','2025-03-01T10:00:00.000000+00:00'),
('canvas_proposal-1','canvas-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('canvas_proposal-2','missing-parent','','missing-parent','missing-parent','','','','',14,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `canvas_thread` (
  `id` varchar(255) NOT NULL,
  `canvas_id` varchar(255) NOT NULL,
  `number` int(11) NOT NULL,
  `board_id` longtext DEFAULT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `page` longtext DEFAULT NULL,
  `anchor` longtext DEFAULT NULL,
  `status` longtext NOT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `resolved_by` longtext DEFAULT NULL,
  `resolved_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_canvas_thread_canvas_id` (`canvas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `canvas_thread` VALUES
('canvas_thread-0','canvas-0',0,'board-0',0.25,0.25,'page 0','anchor 0','status 0','created_by 0','2025-03-01T10:00:00.000000+00:00','resolved_by 0','2025-03-01T10:00:00.000000+00:00'),
('canvas_thread-1','canvas-1',7,NULL,1.75,1.75,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('canvas_thread-2','missing-parent',14,'missing-parent',3.25,3.25,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `canvas_version` (
  `id` varchar(255) NOT NULL,
  `canvas_id` varchar(255) NOT NULL,
  `version` int(11) NOT NULL,
  `name` longtext DEFAULT NULL,
  `reason` longtext NOT NULL,
  `author` longtext NOT NULL,
  `note` longtext DEFAULT NULL,
  `changes` longtext NOT NULL,
  `summary` longtext NOT NULL,
  `doc` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_canvas_version` (`canvas_id`,`version`),
  KEY `ix_canvas_version_canvas_id` (`canvas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `canvas_version` VALUES
('canvas_version-0','canvas-0',0,'name 0','reason 0','author 0','note 0','changes 0','summary 0','doc 0','2025-03-01T10:00:00.000000+00:00'),
('canvas_version-1','canvas-1',7,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('canvas_version-2','missing-parent',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagram` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `label` longtext NOT NULL,
  `summary` longtext NOT NULL,
  `item_kind` longtext DEFAULT NULL,
  `item_id` varchar(255) DEFAULT NULL,
  `version` int(11) NOT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_by` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `deleted_at` longtext DEFAULT NULL,
  `deleted_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_diagram_project_id` (`project_id`),
  KEY `ix_diagram_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `diagram` VALUES
('diagram-0','p-1','label 0','summary 0','item_kind 0','item-0',0,'created_by 0','2025-03-01T10:00:00.000000+00:00','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','deleted_by 0'),
('diagram-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('diagram-2','p-missing','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent',14,'','2025-05-05T05:05:05.555555+00:00','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagram_settings` (
  `id` int(11) NOT NULL,
  `mode` longtext NOT NULL,
  `url` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `diagram_settings` VALUES
(1,'mode 0','url 0'),
(2,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
(3,'','');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagram_version` (
  `id` varchar(255) NOT NULL,
  `diagram_id` varchar(255) NOT NULL,
  `version` int(11) NOT NULL,
  `source` longtext NOT NULL,
  `svg` longtext NOT NULL,
  `preview_kind` longtext NOT NULL,
  `author` longtext NOT NULL,
  `note` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_diagram_version_diagram_id` (`diagram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `diagram_version` VALUES
('diagram_version-0','diagram-0',0,'source 0','svg 0','preview_kind 0','author 0','note 0','2025-03-01T10:00:00.000000+00:00'),
('diagram_version-1','diagram-1',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('diagram_version-2','missing-parent',14,'','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_check` (
  `page_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `state` longtext NOT NULL,
  `reasons` longtext NOT NULL,
  `based_on_version` int(11) NOT NULL,
  `deps_hash` longtext NOT NULL,
  `checked_at` longtext NOT NULL,
  `ok_until` longtext DEFAULT NULL,
  `ok_hash` longtext DEFAULT NULL,
  `dismissed` longtext NOT NULL,
  `job_id` longtext DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  KEY `ix_docs_ai_check_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_check` VALUES
('docs_ai_check-0','p-1','state 0','reasons 0',0,'deps_hash 0','2025-03-01T10:00:00.000000+00:00','ok_until 0','ok_hash 0','dismissed 0','job-0'),
('docs_ai_check-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL),
('docs_ai_check-2','p-missing','','',14,'','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','missing-parent');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_health` (
  `project_id` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `checked_at` longtext DEFAULT NULL,
  `digest_at` longtext DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_health` VALUES
('docs_ai_health-0','data 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('docs_ai_health-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL),
('docs_ai_health-2','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_ignore` (
  `page_id` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `by` longtext NOT NULL,
  `at` longtext NOT NULL,
  PRIMARY KEY (`page_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_ignore` VALUES
('docs_ai_ignore-0','docs_ai_ignore-0','by 0','2025-03-01T10:00:00.000000+00:00'),
('docs_ai_ignore-1','docs_ai_ignore-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('docs_ai_ignore-2','docs_ai_ignore-2','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_job` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `page_id` varchar(255) DEFAULT NULL,
  `thread_id` varchar(255) DEFAULT NULL,
  `comment_id` longtext DEFAULT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `kind` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `started_by` longtext NOT NULL,
  `instruction` longtext NOT NULL,
  `session_id` longtext DEFAULT NULL,
  `reads` longtext NOT NULL,
  `steps` longtext NOT NULL,
  `result` longtext NOT NULL,
  `error` longtext NOT NULL,
  `tokens_in` int(11) NOT NULL,
  `tokens_out` int(11) NOT NULL,
  `cost_usd` float NOT NULL,
  `metered` tinyint(1) NOT NULL,
  `reply_comment_id` longtext DEFAULT NULL,
  `queued_at` longtext NOT NULL,
  `started_at` longtext DEFAULT NULL,
  `ended_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_ai_job_thread_id` (`thread_id`),
  KEY `ix_docs_ai_job_member_id` (`member_id`),
  KEY `ix_docs_ai_job_project_id` (`project_id`),
  KEY `ix_docs_ai_job_kind` (`kind`),
  KEY `ix_docs_ai_job_page_id` (`page_id`),
  KEY `ix_docs_ai_job_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_job` VALUES
('docs_ai_job-0','p-1','page-0','thread-0','comment-0','member-0','kind 0','state 0','started_by 0','instruction 0','session-0','reads 0','steps 0','result 0','error 0',0,0,0.25,0,'reply_comment-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('docs_ai_job-1','p-2',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,1.75,1,NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('docs_ai_job-2','p-missing','missing-parent','missing-parent','missing-parent','missing-parent','','','','','missing-parent','','','','',14,14,3.25,0,'missing-parent','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_proposal` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `run_id` longtext DEFAULT NULL,
  `job_id` longtext DEFAULT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `approval_id` longtext DEFAULT NULL,
  `on_behalf_of` longtext DEFAULT NULL,
  `base_version` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `summary` longtext NOT NULL,
  `changes` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `expires_at` longtext DEFAULT NULL,
  `decided_by` longtext DEFAULT NULL,
  `decided_at` longtext DEFAULT NULL,
  `decision_note` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_ai_proposal_status` (`status`),
  KEY `ix_docs_ai_proposal_page_id` (`page_id`),
  KEY `ix_docs_ai_proposal_member_id` (`member_id`),
  KEY `ix_docs_ai_proposal_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_proposal` VALUES
('docs_ai_proposal-0','p-1','page-0','member-0','run-0','job-0','ticket-0','approval-0','on_behalf_of 0',0,'status 0','summary 0','changes 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','decided_by 0','2025-03-01T10:00:00.000000+00:00','decision_note 0'),
('docs_ai_proposal-1','p-2','page-1','member-1',NULL,NULL,NULL,NULL,NULL,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL,NULL),
('docs_ai_proposal-2','p-missing','missing-parent','missing-parent','missing-parent','missing-parent','missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_session` (
  `scope` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `session_id` longtext NOT NULL,
  `calls` int(11) NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`scope`,`member_id`),
  KEY `ix_docs_ai_session_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_session` VALUES
('docs_ai_session-0','docs_ai_session-0','p-1','session-0',0,'2025-03-01T10:00:00.000000+00:00'),
('docs_ai_session-1','docs_ai_session-1','p-2','session-1',7,'2025-04-01T00:00:00.000000+00:00'),
('docs_ai_session-2','docs_ai_session-2','p-missing','missing-parent',14,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_ai_settings` (
  `project_id` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `read_scope` longtext NOT NULL,
  `picked_pages` longtext NOT NULL,
  `style_page_id` longtext DEFAULT NULL,
  `edits_mode` longtext NOT NULL,
  `proposal_days` int(11) NOT NULL,
  `freshness_on` tinyint(1) NOT NULL,
  `guidance_limit` int(11) NOT NULL,
  `digest_on` tinyint(1) NOT NULL,
  `updated_by` longtext DEFAULT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_ai_settings` VALUES
('docs_ai_settings-0',0,'member-0','read_scope 0','picked_pages 0','style_page-0','edits_mode 0',0,0,0,0,'updated_by 0','2025-03-01T10:00:00.000000+00:00'),
('docs_ai_settings-1',1,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,1,7,1,NULL,'2025-04-01T00:00:00.000000+00:00'),
('docs_ai_settings-2',0,'missing-parent','','','missing-parent','',14,0,14,0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_anchor_aliases` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `old_slug` longtext NOT NULL,
  `new_slug` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_anchor_aliases_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_anchor_aliases` VALUES
('docs_anchor_aliases-0','page-0','old_slug 0','new_slug 0'),
('docs_anchor_aliases-1','page-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('docs_anchor_aliases-2','missing-parent','','');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_comment` (
  `id` varchar(255) NOT NULL,
  `thread_id` varchar(255) NOT NULL,
  `author` longtext NOT NULL,
  `body` longtext NOT NULL,
  `mentions` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `edited_at` longtext DEFAULT NULL,
  `ai` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_comment_thread_id` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_comment` VALUES
('docs_comment-0','thread-0','author 0','body 0','mentions 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','ai 0'),
('docs_comment-1','thread-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('docs_comment-2','missing-parent','','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_comment_event` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `page_id` varchar(255) DEFAULT NULL,
  `thread_id` longtext DEFAULT NULL,
  `comment_id` longtext DEFAULT NULL,
  `kind` longtext NOT NULL,
  `actor` longtext NOT NULL,
  `mentioned` longtext NOT NULL,
  `recipients` longtext NOT NULL,
  `page_title` longtext NOT NULL,
  `snippet` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_comment_event_project_id` (`project_id`),
  KEY `ix_docs_comment_event_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_comment_event` VALUES
('docs_comment_event-0','p-1','page-0','thread-0','comment-0','kind 0','actor 0','mentioned 0','recipients 0','page_title 0','snippet 0','2025-03-01T10:00:00.000000+00:00'),
('docs_comment_event-1','p-2',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('docs_comment_event-2','p-missing','missing-parent','missing-parent','missing-parent','','','','','','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_comment_read` (
  `id` varchar(255) NOT NULL,
  `thread_id` varchar(255) NOT NULL,
  `reader` longtext NOT NULL,
  `read_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_comment_read_thread_id` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_comment_read` VALUES
('docs_comment_read-0','thread-0','reader 0','2025-03-01T10:00:00.000000+00:00'),
('docs_comment_read-1','thread-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('docs_comment_read-2','missing-parent','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_comment_thread` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `status` longtext NOT NULL,
  `anchor_quote` longtext DEFAULT NULL,
  `anchor_prefix` longtext NOT NULL,
  `anchor_suffix` longtext NOT NULL,
  `anchor_section` longtext DEFAULT NULL,
  `anchor_state` longtext NOT NULL,
  `anchor_pos` int(11) DEFAULT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `resolved_by` longtext DEFAULT NULL,
  `resolved_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_comment_thread_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_comment_thread` VALUES
('docs_comment_thread-0','page-0','kind 0','status 0','anchor_quote 0','anchor_prefix 0','anchor_suffix 0','anchor_section 0','anchor_state 0',0,'created_by 0','2025-03-01T10:00:00.000000+00:00','resolved_by 0','2025-03-01T10:00:00.000000+00:00'),
('docs_comment_thread-1','page-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('docs_comment_thread-2','missing-parent','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',14,'','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_draft` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `author` longtext NOT NULL,
  `title` longtext NOT NULL,
  `markdown` longtext NOT NULL,
  `base_version` int(11) NOT NULL,
  `saves` int(11) NOT NULL,
  `updated_at` longtext NOT NULL,
  `ai_source` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_draft_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_draft` VALUES
('d-1','pg-draft','author 0','title 0','## Draft heading\nbody',0,0,'2025-03-01T10:00:00.000000+00:00','ai_source 0'),
('d-2','pg-published','author 0','title 0','## Draft of a published page',0,0,'2025-03-01T10:00:00.000000+00:00','ai_source 0'),
('d-3','pg-wrong-version','author 0','title 0','# From the draft ## after a line separator',0,0,'2025-03-01T10:00:00.000000+00:00','ai_source 0'),
('docs_draft-0','page-0','author 0','title 0','markdown 0',0,0,'2025-03-01T10:00:00.000000+00:00','ai_source 0'),
('docs_draft-1','page-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,'2025-04-01T00:00:00.000000+00:00',NULL),
('docs_draft-2','missing-parent','','','',14,14,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_link` (
  `id` varchar(255) NOT NULL,
  `source_page_id` varchar(255) NOT NULL,
  `source_section` longtext DEFAULT NULL,
  `target_page_id` varchar(255) DEFAULT NULL,
  `target_title` longtext DEFAULT NULL,
  `target_anchor` longtext DEFAULT NULL,
  `target_ticket_id` varchar(255) DEFAULT NULL,
  `display_text` longtext DEFAULT NULL,
  `snippet` longtext NOT NULL,
  `origin` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_link_source_page_id` (`source_page_id`),
  KEY `ix_docs_link_target_ticket_id` (`target_ticket_id`),
  KEY `ix_docs_link_target_page_id` (`target_page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_link` VALUES
('docs_link-0','source_page-0','source_section 0','target_page-0','target_title 0','target_anchor 0','target_ticket-0','display_text 0','snippet 0','origin 0'),
('docs_link-1','source_page-1',NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('docs_link-2','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_page` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `slug` longtext NOT NULL,
  `status` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `created_by` longtext NOT NULL,
  `updated_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `deleted_at` longtext DEFAULT NULL,
  `deleted_by` longtext DEFAULT NULL,
  `deleted_root_id` longtext DEFAULT NULL,
  `ai_hidden` tinyint(1) NOT NULL,
  `ai_guidance` tinyint(1) NOT NULL,
  `kind` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_page_parent_id` (`parent_id`),
  KEY `ix_docs_page_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_page` VALUES
('docs_page-0','p-1','parent-0',0,'title 0','slug 0','status 0',0,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','deleted_by 0','deleted_root-0',0,0,'kind 0'),
('docs_page-1','p-2',NULL,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('docs_page-2','p-missing','missing-parent',14,'','','',14,'','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent',0,0,''),
('pg-deleted','p-1','parent-0',0,'In the bin','slug 0','status 0',1,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','deleted_by 0','deleted_root-0',0,0,'kind 0'),
('pg-draft','p-1','parent-0',0,'Only a draft','slug 0','status 0',0,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',NULL,'deleted_by 0','deleted_root-0',0,0,'kind 0'),
('pg-empty','p-2','parent-0',0,'Nothing written ü','slug 0','status 0',0,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',NULL,'deleted_by 0','deleted_root-0',0,0,'kind 0'),
('pg-published','p-1','parent-0',0,'Published page','slug 0','status 0',2,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',NULL,'deleted_by 0','deleted_root-0',0,0,'kind 0'),
('pg-wrong-version','p-1','parent-0',0,'Version row missing','slug 0','status 0',7,'created_by 0','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00',NULL,'deleted_by 0','deleted_root-0',0,0,'kind 0');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_page_seen` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `viewer` longtext NOT NULL,
  `version` int(11) NOT NULL,
  `seen_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_page_seen_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_page_seen` VALUES
('docs_page_seen-0','page-0','viewer 0',0,'2025-03-01T10:00:00.000000+00:00'),
('docs_page_seen-1','page-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'2025-04-01T00:00:00.000000+00:00'),
('docs_page_seen-2','missing-parent','',14,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_title_aliases` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `old_title` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_title_aliases_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_title_aliases` VALUES
('docs_title_aliases-0','page-0','old_title 0'),
('docs_title_aliases-1','page-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('docs_title_aliases-2','missing-parent','');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docs_version` (
  `id` varchar(255) NOT NULL,
  `page_id` varchar(255) NOT NULL,
  `version` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `markdown` longtext NOT NULL,
  `author` longtext NOT NULL,
  `note` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `diagram_versions` longtext NOT NULL,
  `with_ai` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_docs_version_page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `docs_version` VALUES
('docs_version-0','page-0',0,'title 0','markdown 0','author 0','note 0','2025-03-01T10:00:00.000000+00:00','diagram_versions 0',0),
('docs_version-1','page-1',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1),
('docs_version-2','missing-parent',14,'','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','',0),
('v-1','pg-published',1,'title 0','# Old title\n\nold','author 0','note 0','2025-03-01T10:00:00.000000+00:00','diagram_versions 0',0),
('v-2','pg-published',2,'title 0','# One *big* title #\ntext\n```\n# not a heading\n```\n## [[Other page#part|shown]] and [a link](http://x)\r\n#nospace\n### ==mark== `code` ~~gone~~\n   ~~~\n## in a fence\n~~~\n###### Tiêu đề sâu 日本語 ##\n####### seven\n#	 Tabbed\n## \n## [[Plain]] __bold__\n','author 0','note 0','2025-03-01T10:00:00.000000+00:00','diagram_versions 0',0),
('v-3','pg-deleted',1,'title 0','# Deleted','author 0','note 0','2025-03-01T10:00:00.000000+00:00','diagram_versions 0',0),
('v-4','pg-wrong-version',1,'title 0','# Not the current version','author 0','note 0','2025-03-01T10:00:00.000000+00:00','diagram_versions 0',0);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_advice` (
  `id` varchar(255) NOT NULL,
  `idea_id` varchar(255) NOT NULL,
  `action` longtext NOT NULL,
  `reason` longtext NOT NULL,
  `confidence` longtext NOT NULL,
  `target_id` longtext DEFAULT NULL,
  `archive_reason` longtext DEFAULT NULL,
  `park_days` int(11) DEFAULT NULL,
  `idea_stamp` longtext NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `cost` float NOT NULL,
  `state` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_advice_idea_id` (`idea_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_advice` VALUES
('idea_advice-0','idea-0','action 0','reason 0','confidence 0','target-0','archive_reason 0',0,'idea_stamp 0','member-0',0.25,'state 0','2025-03-01T10:00:00.000000+00:00'),
('idea_advice-1','idea-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,1.75,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('idea_advice-2','missing-parent','','','','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'','missing-parent',3.25,'','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_ai_settings` (
  `project_id` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `triage_advice` tinyint(1) NOT NULL,
  `weekly_grooming` tinyint(1) NOT NULL,
  `ask` tinyint(1) NOT NULL,
  `read_docs` tinyint(1) NOT NULL,
  `read_repo` tinyint(1) NOT NULL,
  `daily_cap` float NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_ai_settings` VALUES
('idea_ai_settings-0',0,0,0,0,0,0,0.25,'2025-03-01T10:00:00.000000+00:00'),
('idea_ai_settings-1',1,1,1,1,1,1,1.75,'2025-04-01T00:00:00.000000+00:00'),
('idea_ai_settings-2',0,0,0,0,0,0,3.25,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_assumption` (
  `id` varchar(255) NOT NULL,
  `idea_id` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `text` longtext NOT NULL,
  `impact` longtext NOT NULL,
  `status` longtext NOT NULL,
  `test_ticket_id` longtext DEFAULT NULL,
  `ai` tinyint(1) NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_assumption_idea_id` (`idea_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_assumption` VALUES
('idea_assumption-0','idea-0',0,'text 0','impact 0','status 0','test_ticket-0',0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('idea_assumption-1','idea-1',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,1,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('idea_assumption-2','missing-parent',14,'','','','missing-parent',0,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_comment` (
  `id` varchar(255) NOT NULL,
  `idea_id` varchar(255) NOT NULL,
  `author` longtext DEFAULT NULL,
  `body` longtext NOT NULL,
  `ai` tinyint(1) NOT NULL,
  `run_id` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `edited_at` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_comment_idea_id` (`idea_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_comment` VALUES
('idea_comment-0','idea-0','author 0','body 0',0,'run-0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('idea_comment-1','idea-1',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,'2025-04-01T00:00:00.000000+00:00',NULL),
('idea_comment-2','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',0,'missing-parent','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_counter` (
  `id` int(11) NOT NULL,
  `counter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_counter` VALUES
(1,0),
(2,7),
(3,14);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_digest` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `text` longtext NOT NULL,
  `items` longtext NOT NULL,
  `ai` tinyint(1) NOT NULL,
  `member_id` longtext DEFAULT NULL,
  `cost` float NOT NULL,
  `ideas_read` int(11) NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_digest_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_digest` VALUES
('idea_digest-0','p-1','text 0','items 0',0,'member-0',0.25,0,'2025-03-01T10:00:00.000000+00:00'),
('idea_digest-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,1.75,7,'2025-04-01T00:00:00.000000+00:00'),
('idea_digest-2','p-missing','','',0,'missing-parent',3.25,14,'2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_evidence` (
  `id` varchar(255) NOT NULL,
  `assumption_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `title` longtext NOT NULL,
  `ref` longtext NOT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_evidence_assumption_id` (`assumption_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_evidence` VALUES
('idea_evidence-0','assumption-0','kind 0','title 0','ref 0','created_by 0','2025-03-01T10:00:00.000000+00:00'),
('idea_evidence-1','assumption-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('idea_evidence-2','missing-parent','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_log_entry` (
  `id` varchar(255) NOT NULL,
  `idea_id` varchar(255) NOT NULL,
  `kind` longtext NOT NULL,
  `body` longtext NOT NULL,
  `author` longtext DEFAULT NULL,
  `ai` tinyint(1) NOT NULL,
  `pinned` tinyint(1) NOT NULL,
  `assumption_id` longtext DEFAULT NULL,
  `attachments` longtext NOT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_log_entry_idea_id` (`idea_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_log_entry` VALUES
('idea_log_entry-0','idea-0','kind 0','body 0','author 0',0,0,'assumption-0','attachments 0','ticket-0','2025-03-01T10:00:00.000000+00:00'),
('idea_log_entry-1','idea-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,1,1,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00'),
('idea_log_entry-2','missing-parent','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,0,'missing-parent','','missing-parent','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_ticket` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `idea_status` longtext NOT NULL,
  `stage` varchar(255) NOT NULL,
  `park_until` longtext DEFAULT NULL,
  `archive_reason` longtext DEFAULT NULL,
  `source` longtext NOT NULL,
  `source_ref` longtext NOT NULL,
  `created_by` longtext DEFAULT NULL,
  `owner` longtext DEFAULT NULL,
  `park_note` longtext DEFAULT NULL,
  `archive_note` longtext DEFAULT NULL,
  `stage_changed_at` longtext DEFAULT NULL,
  `prev_state` longtext NOT NULL,
  `merged_into_id` longtext DEFAULT NULL,
  `merged_at` longtext DEFAULT NULL,
  `merge_undo` longtext NOT NULL,
  `shipped_at` longtext DEFAULT NULL,
  `outcome` longtext DEFAULT NULL,
  `outcome_note` longtext DEFAULT NULL,
  `former_ticket_id` longtext DEFAULT NULL,
  `effort_guess` longtext DEFAULT NULL,
  `workspace_retention` longtext NOT NULL,
  `body` longtext NOT NULL,
  `details` longtext NOT NULL,
  `idea_color` longtext NOT NULL,
  `idea_emoji` longtext NOT NULL,
  `idea_energy` longtext DEFAULT NULL,
  `tags` longtext NOT NULL,
  `problem_statement` longtext DEFAULT NULL,
  `ice_impact` int(11) NOT NULL,
  `ice_effort` int(11) NOT NULL,
  `ice_confidence` int(11) NOT NULL,
  `revisit_date` longtext DEFAULT NULL,
  `last_touched_at` longtext DEFAULT NULL,
  `promoted_to_ticket_id` longtext DEFAULT NULL,
  `promoted_at` longtext DEFAULT NULL,
  `activity_trail` longtext NOT NULL,
  `microthoughts` longtext NOT NULL,
  `assumptions` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_idea_ticket_project_id` (`project_id`),
  KEY `ix_idea_ticket_stage` (`stage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_ticket` VALUES
('i-approved-done','p-1','Idea i-approved-done','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','t-done','2025-03-01T10:00:00.000000+00:00','[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-empty','p-1','Idea i-approved-empty','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','',NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-gone','p-1','Idea i-approved-gone','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','t-missing','2025-03-01T10:00:00.000000+00:00','[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-nobody-revisit','p-1','Idea i-approved-nobody-revisit','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,'2025-12-03','2025-03-01T10:00:00.000000+00:00','t-nobody',NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-none','p-1','Idea i-approved-none','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-none-revisit','p-1','Idea i-approved-none-revisit','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,' 2025-12-02 ','2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-open','p-1','Idea i-approved-open','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','t-open','2025-03-01T10:00:00.000000+00:00','[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-approved-wontdo','p-1','Idea i-approved-wontdo','description 0','approved','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','t-wontdo','2025-03-01T10:00:00.000000+00:00','[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-bad-json','p-1','Idea i-bad-json','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'not json','{\"a\": 1}','null','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-body','p-1','Idea i-body','  What it is\nsecond line  ','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','high','tags 0','  Why it matters ü  ',5,1,4,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"u1\", \"label\": \"T\\u1ea1o \\u00fd t\\u01b0\\u1edfng \\ud83d\\udca1\", \"at\": \"2025-01-01\", \"author\": null, \"n\": 1.0, \"f\": 0.1, \"big\": 12345678901234567890, \"neg\": -1.5e-07, \"nested\": {\"b\": [true, false, null], \"a\": \"\\u00e9\"}}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-description-only','p-1','Idea i-description-only','Only a description','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','','tags 0',NULL,0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-draft-assume','p-1','Idea i-draft-assume','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[{\"id\": \"as-1\", \"text\": \"users want it\", \"status\": \"validated\", \"at\": \"2025-01-03T00:00:00+00:00\"}, {\"text\": \" cheap to build \", \"status\": \"invalidated\"}, {\"id\": \"as-3\", \"text\": \"x\", \"status\": \"untested\"}, {\"id\": \"as-4\", \"text\": \"y\", \"status\": \"weird\"}, {\"id\": \"as-5\", \"text\": \"z\"}, {\"id\": \"as-6\", \"text\": \"\"}, 5, {\"id\": \"as-7\", \"text\": \"status is a number\", \"status\": 3}, {\"id\": \"as-8\", \"text\": 0, \"status\": null, \"at\": 0}]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-draft-fresh','p-1','Idea i-draft-fresh','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-draft-micro','p-1','Idea i-draft-micro','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[{\"id\": \"mt-1\", \"text\": \"  a thought  \", \"at\": \"2025-01-02T00:00:00+00:00\"}, {\"text\": \"no id, no time \\u00e9\"}, {\"id\": \"mt-3\", \"text\": \"   \"}, \"not an object\", {\"id\": 7, \"text\": 12.5}, {\"id\": \"mt-null\", \"text\": null}, {\"id\": \"mt-bool\", \"text\": true, \"at\": \"\"}, {\"id\": \"\", \"text\": \"empty id\"}, {\"id\": \"mt-missing-text\"}]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-draft-no-trail','p-1','Idea i-draft-no-trail','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[]','[]','[]','2025-03-01T10:00:00.000000+00:00',''),
('i-draft-revisit','p-1','Idea i-draft-revisit','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,'2025-12-04','2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-draft-touched','p-1','Idea i-draft-touched','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-dropped','p-1','Idea i-dropped','description 0','dropped','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-dropped-revisit','p-1','Idea i-dropped-revisit','description 0','dropped','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,'2025-12-01','2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-empty-json','p-1','Idea i-empty-json','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'','','','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-no-project','p-missing','Idea i-no-project','description 0','draft','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-old-brewing','p-1','Idea i-old-brewing','description 0','brewing','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','orange','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-old-raw','p-1','Idea i-old-raw','description 0','raw','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','#F5C518','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-old-validated','p-1','Idea i-old-validated','description 0','validated','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','teal','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-problem-only','p-1','Idea i-problem-only','','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','Only a problem',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-review','p-1','Idea i-review','description 0','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[{\"id\": \"mu-1\", \"text\": \"  a thought  \", \"at\": \"2025-01-02T00:00:00+00:00\"}, {\"text\": \"no id, no time \\u00e9\"}, {\"id\": \"mu-3\", \"text\": \"   \"}, \"not an object\", {\"id\": 8, \"text\": 12.5}, {\"id\": \"mu-null\", \"text\": null}, {\"id\": \"mu-bool\", \"text\": true, \"at\": \"\"}, {\"id\": \"\", \"text\": \"empty id\"}, {\"id\": \"mu-missing-text\"}]','[{\"id\": \"at-1\", \"text\": \"users want it\", \"status\": \"validated\", \"at\": \"2025-01-03T00:00:00+00:00\"}, {\"text\": \" cheap to build \", \"status\": \"invalidated\"}, {\"id\": \"at-3\", \"text\": \"x\", \"status\": \"untested\"}, {\"id\": \"at-4\", \"text\": \"y\", \"status\": \"weird\"}, {\"id\": \"at-5\", \"text\": \"z\"}, {\"id\": \"at-6\", \"text\": \"\"}, 5, {\"id\": \"at-7\", \"text\": \"status is a number\", \"status\": 3}, {\"id\": \"at-8\", \"text\": 0, \"status\": null, \"at\": 0}]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-review-revisit','p-1','Idea i-review-revisit','description 0','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,'   ','2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-review-wontdo','p-1','Idea i-review-wontdo','description 0','in_review','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00','t-wontdo2',NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('i-unknown','p-1','Idea i-unknown','description 0','something else','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','yellow','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,NULL,'2025-03-01T10:00:00.000000+00:00',NULL,NULL,'[{\"id\": \"tr-0\", \"label\": \"Step 0 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}, {\"id\": \"tr-1\", \"label\": \"Step 1 \\u2014 \\u2713\", \"at\": \"2025-01-01T00:00:00+00:00\", \"author\": \"Minh\"}]','[]','[]','2025-03-01T10:00:00.000000+00:00','2025-03-02T10:00:00.000000+00:00'),
('idea_ticket-0','p-1','title 0','description 0','idea_status 0','stage 0','park_until 0','archive_reason 0','source 0','source_ref 0','created_by 0','owner 0','park_note 0','archive_note 0','2025-03-01T10:00:00.000000+00:00','prev_state 0','merged_into-0','2025-03-01T10:00:00.000000+00:00','merge_undo 0','2025-03-01T10:00:00.000000+00:00','outcome 0','outcome_note 0','former_ticket-0','effort_guess 0','workspace_retention 0','body 0','details 0','idea_color 0','idea_emoji 0','idea_energy 0','tags 0','problem_statement 0',0,0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','promoted_to_ticket-0','2025-03-01T10:00:00.000000+00:00','activity_trail 0','microthoughts 0','assumptions 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('idea_ticket-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,7,7,7,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('idea_ticket-2','p-missing','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','','missing-parent','2025-05-05T05:05:05.555555+00:00','','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,14,14,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','missing-parent','2025-05-05T05:05:05.555555+00:00','','','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idea_vote` (
  `id` varchar(255) NOT NULL,
  `idea_id` varchar(255) NOT NULL,
  `voter` varchar(255) NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_idea_vote_idea_voter` (`idea_id`,`voter`),
  KEY `ix_idea_vote_idea_id` (`idea_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `idea_vote` VALUES
('idea_vote-0','idea-0','voter 0','2025-03-01T10:00:00.000000+00:00'),
('idea_vote-1','idea-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('idea_vote-2','missing-parent','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kanban_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `origin` varchar(32) NOT NULL,
  `at` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `name` longtext NOT NULL,
  `color` longtext NOT NULL,
  `role` longtext NOT NULL,
  `kind` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_member_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `member` VALUES
('m-ai','p-1','Bot','#222222','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-ai-removed','p-1','Old bot','#333333','role 0','ai_removed','2025-03-01T10:00:00.000000+00:00'),
('m-anthropic','p-2','anthropic','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-antigravity','p-2','antigravity','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-claude-code','p-2','claude-code','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-custom','p-2','custom','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-gemini','p-2','gemini','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-human','p-1','Ann','#111111','role 0','human','2025-03-01T10:00:00.000000+00:00'),
('m-human-with-profile','p-2','Not AI','#444444','role 0','human','2025-03-01T10:00:00.000000+00:00'),
('m-mcp-client','p-2','mcp-client','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-openai','p-2','openai','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('m-unknown','p-2','unknown','#000000','role 0','ai','2025-03-01T10:00:00.000000+00:00'),
('member-0','p-1','name 0','color 0','role 0','kind 0','2025-03-01T10:00:00.000000+00:00'),
('member-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('member-2','p-missing','','','','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` varchar(255) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `event_id` int(11) NOT NULL,
  `last_event_id` int(11) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `kind` varchar(255) NOT NULL,
  `needs` tinyint(1) NOT NULL,
  `group_key` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `items` longtext NOT NULL,
  `target_kind` longtext DEFAULT NULL,
  `target_id` varchar(255) DEFAULT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `page_id` longtext DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `actor` longtext DEFAULT NULL,
  `title` longtext NOT NULL,
  `body` longtext NOT NULL,
  `data` longtext NOT NULL,
  `inapp` tinyint(1) NOT NULL,
  `desktop` tinyint(1) NOT NULL,
  `read_at` longtext DEFAULT NULL,
  `done_at` varchar(255) DEFAULT NULL,
  `done_reason` longtext DEFAULT NULL,
  `done_by` longtext DEFAULT NULL,
  `snoozed_until` longtext DEFAULT NULL,
  `cleared_at` longtext DEFAULT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_notification_project_id` (`project_id`),
  KEY `ix_notification_created_at` (`created_at`),
  KEY `ix_notification_open_needs` (`needs`,`done_at`),
  KEY `ix_notification_recipient` (`recipient`),
  KEY `ix_notification_kind` (`kind`),
  KEY `ix_notification_target_id` (`target_id`),
  KEY `ix_notification_updated_at` (`updated_at`),
  KEY `ix_notification_event_id` (`event_id`),
  KEY `ix_notification_recipient_open` (`recipient`,`done_at`),
  KEY `ix_notification_last_event_id` (`last_event_id`),
  KEY `ix_notification_group_key` (`group_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `notification` VALUES
('n-ai_done','user',0,0,'p-1','ai_done',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-approval','user',0,0,'p-1','approval',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-blocked','user',0,0,'p-1','blocked',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-mention','user',0,0,'p-1','mention',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-page_proposal','user',0,0,'p-1','page_proposal',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-run_restarted','user',0,0,'p-1','run_restarted',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-story_blocked','user',0,0,'p-1','story_blocked',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-story_done','user',0,0,'p-1','story_done',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('n-story_plan','user',0,0,'p-1','story_plan',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('notification-0','recipient 0',0,0,'p-1','kind 0',0,'group_key 0',0,'items 0','target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0',0,0,'2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','done_reason 0','done_by 0','snoozed_until 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('notification-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,'p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,1,NULL,NULL,NULL,NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('notification-2','',14,14,'p-missing','',0,'',14,'','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent','missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','',0,0,'2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(255) DEFAULT NULL,
  `kind` varchar(255) NOT NULL,
  `op` longtext NOT NULL,
  `needs` tinyint(1) NOT NULL,
  `target_kind` longtext DEFAULT NULL,
  `target_id` varchar(255) DEFAULT NULL,
  `ticket_id` longtext DEFAULT NULL,
  `page_id` longtext DEFAULT NULL,
  `member_id` longtext DEFAULT NULL,
  `actor` longtext DEFAULT NULL,
  `title` longtext NOT NULL,
  `body` longtext NOT NULL,
  `data` longtext NOT NULL,
  `recipients` longtext NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_notify_event_project_id` (`project_id`),
  KEY `ix_notify_event_target_id` (`target_id`),
  KEY `ix_notify_event_created_at` (`created_at`),
  KEY `ix_notify_event_kind` (`kind`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `notify_event` VALUES
(1,'p-1','kind 0','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(2,'p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,NULL,NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
(3,'p-missing','','',0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent','missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','','','2025-05-05T05:05:05.555555+00:00'),
(100,'p-1','page_proposal','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(101,'p-1','approval','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(102,'p-1','blocked','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(103,'p-1','run_restarted','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(104,'p-1','story_plan','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(105,'p-1','story_blocked','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(106,'p-1','story_done','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00'),
(107,'p-1','mention','op 0',0,'target_kind 0','target-0','ticket-0','page-0','member-0','actor 0','title 0','body 0','data 0','recipients 0','2025-03-01T10:00:00.000000+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_follow` (
  `id` varchar(255) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `scope` longtext NOT NULL,
  `scope_id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `level` longtext NOT NULL,
  `until` longtext DEFAULT NULL,
  `label` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_notify_follow_recipient` (`recipient`),
  KEY `ix_notify_follow_project_id` (`project_id`),
  KEY `ix_notify_follow_scope_id` (`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `notify_follow` VALUES
('nf-1','user','kind','approval','p-1','level 0','until 0','label 0','2025-03-01T10:00:00.000000+00:00'),
('nf-2','user','kind','mention','p-1','level 0','until 0','label 0','2025-03-01T10:00:00.000000+00:00'),
('nf-3','user','space','approval','p-1','level 0','until 0','label 0','2025-03-01T10:00:00.000000+00:00'),
('nf-4','ann','kind','story_done','p-1','level 0','until 0','label 0','2025-03-01T10:00:00.000000+00:00'),
('notify_follow-0','recipient 0','scope 0','scope-0','p-1','level 0','until 0','label 0','2025-03-01T10:00:00.000000+00:00'),
('notify_follow-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','scope-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('notify_follow-2','','','missing-parent','p-missing','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notify_prefs` (
  `recipient` varchar(255) NOT NULL,
  `prefs` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `notify_prefs` VALUES
('notify_prefs-0','prefs 0','2025-03-01T10:00:00.000000+00:00'),
('notify_prefs-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00'),
('notify_prefs-2','','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `id` varchar(255) NOT NULL,
  `name` longtext NOT NULL,
  `prefix` varchar(255) NOT NULL,
  `color` longtext NOT NULL,
  `ticket_counter` int(11) NOT NULL,
  `repo_path` longtext DEFAULT NULL,
  `worktree_template` longtext DEFAULT NULL,
  `worktree_by_default` tinyint(1) NOT NULL,
  `docs_enabled` tinyint(1) NOT NULL,
  `docs_edit_policy` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prefix` (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `project` VALUES
('p-1','One','ONE','color 0',0,'repo_path 0','worktree_template 0',0,0,'docs_edit_policy 0'),
('p-2','Two ü','TWO','color 0',0,'repo_path 0','worktree_template 0',0,0,'docs_edit_policy 0'),
('project-0','name 0','GEN0','color 0',0,'repo_path 0','worktree_template 0',0,0,'docs_edit_policy 0'),
('project-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','GEN1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,NULL,NULL,1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back'),
('project-2','','GEN2','',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',0,0,'');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sketch` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) DEFAULT NULL,
  `owner_kind` longtext NOT NULL,
  `owner_id` varchar(255) NOT NULL,
  `title` longtext NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `layer_count` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  `png_bytes` int(11) NOT NULL,
  `source_bytes` int(11) NOT NULL,
  `created_by` longtext NOT NULL,
  `created_at` longtext NOT NULL,
  `updated_by` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  `deleted_at` longtext DEFAULT NULL,
  `deleted_by` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sketch_project_id` (`project_id`),
  KEY `ix_sketch_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `sketch` VALUES
('sketch-0','p-1','owner_kind 0','owner-0','title 0',0,0,0,0,0,0,'created_by 0','2025-03-01T10:00:00.000000+00:00','updated_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','deleted_by 0'),
('sketch-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','owner-1','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,7,7,7,7,7,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-04-01T00:00:00.000000+00:00',NULL,NULL),
('sketch-2','p-missing','','missing-parent','',14,14,14,14,14,14,'','2025-05-05T05:05:05.555555+00:00','','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `story` (
  `ticket_id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `approve` longtext NOT NULL,
  `budget_tokens` int(11) NOT NULL,
  `pm_id` longtext DEFAULT NULL,
  `plan` longtext NOT NULL,
  `paused` tinyint(1) NOT NULL,
  `review_note` longtext DEFAULT NULL,
  `history` longtext NOT NULL,
  `meta` longtext NOT NULL,
  `created_by` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `handed_at` longtext DEFAULT NULL,
  `started_at` longtext DEFAULT NULL,
  `closed_at` longtext DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `ix_story_project_id` (`project_id`),
  KEY `ix_story_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `story` VALUES
('story-0','p-1','state 0','approve 0',0,'pm-0','plan 0',0,'review_note 0','history 0','meta 0','created_by 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('story-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',7,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'2025-04-01T00:00:00.000000+00:00',NULL,NULL,NULL),
('story-2','p-missing','','',14,'missing-parent','',0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `id` varchar(255) NOT NULL,
  `project_id` varchar(255) NOT NULL,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `type` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `priority` longtext NOT NULL,
  `estimate` float DEFAULT NULL,
  `due_date` longtext DEFAULT NULL,
  `tags` longtext NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  `comments` longtext NOT NULL,
  `acceptance_criteria` longtext NOT NULL,
  `sub_tasks` longtext NOT NULL,
  `activity_log` longtext NOT NULL,
  `work_log` longtext NOT NULL,
  `test_cases` longtext NOT NULL,
  `start_date` longtext DEFAULT NULL,
  `wont_do_reason` longtext DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `assignee` varchar(255) DEFAULT NULL,
  `blocks` longtext NOT NULL,
  `blocked_by` longtext NOT NULL,
  `block_done_if_acs_incomplete` tinyint(1) NOT NULL,
  `block_done_if_tcs_incomplete` tinyint(1) NOT NULL,
  `links` longtext NOT NULL,
  `branches` longtext NOT NULL,
  `workspace_retention_days` int(11) DEFAULT NULL,
  `repo_path` longtext DEFAULT NULL,
  `reopen_count` int(11) NOT NULL,
  `last_reopened_at` longtext DEFAULT NULL,
  `last_reopened_by` longtext DEFAULT NULL,
  `last_reopen_reason` longtext DEFAULT NULL,
  `reopen_history` longtext NOT NULL,
  `pending` tinyint(1) NOT NULL,
  `pending_reason_type` longtext DEFAULT NULL,
  `pending_ticket_id` longtext DEFAULT NULL,
  `pending_member_id` longtext DEFAULT NULL,
  `pending_party` longtext DEFAULT NULL,
  `pending_note` longtext DEFAULT NULL,
  `pending_since` longtext DEFAULT NULL,
  `pending_by` longtext DEFAULT NULL,
  `from_idea_id` varchar(255) DEFAULT NULL,
  `tests_assumption_id` varchar(255) DEFAULT NULL,
  `wave_pin` int(11) DEFAULT NULL,
  `review_requested_from` longtext DEFAULT NULL,
  `created_at` longtext NOT NULL,
  `updated_at` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ticket_parent_id` (`parent_id`),
  KEY `ix_ticket_assignee` (`assignee`),
  KEY `ix_ticket_project_status` (`project_id`,`status`),
  KEY `ix_ticket_from_idea_id` (`from_idea_id`),
  KEY `ix_ticket_tests_assumption_id` (`tests_assumption_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ticket` VALUES
('t-done','p-1','title 0','description 0','type 0','done','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0','m-human','blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('t-nobody','p-2','title 0','description 0','type 0','todo','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0',NULL,'blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('t-open','p-1','title 0','description 0','type 0','in-progress','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0','m-gone','blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('t-wontdo','p-1','title 0','description 0','type 0','wont_do','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0','m-ai','blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('t-wontdo2','p-1','title 0','description 0','type 0','wont_do','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0','m-ai-removed','blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ticket-0','p-1','title 0','description 0','type 0','status 0','priority 0',0.25,'2025-03-01T10:00:00.000000+00:00','tags 0','parent-0','comments 0','acceptance_criteria 0','sub_tasks 0','activity_log 0','work_log 0','test_cases 0','2025-03-01T10:00:00.000000+00:00','wont_do_reason 0','created_by 0','assignee 0','blocks 0','blocked_by 0',0,0,'links 0','branches 0',0,'repo_path 0',0,'2025-03-01T10:00:00.000000+00:00','last_reopened_by 0','last_reopen_reason 0','reopen_history 0',0,'pending_reason_type 0','pending_ticket-0','pending_member-0','pending_party 0','pending_note 0','pending_since 0','pending_by 0','from_idea-0','tests_assumption-0',0,'review_requested_from 0','2025-03-01T10:00:00.000000+00:00','2025-03-01T10:00:00.000000+00:00'),
('ticket-1','p-2','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL,NULL,7,NULL,NULL,NULL,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-04-01T00:00:00.000000+00:00','2025-04-01T00:00:00.000000+00:00'),
('ticket-2','p-missing','','','','','',3.25,'2025-05-05T05:05:05.555555+00:00','','missing-parent','','','','','','','2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','','',0,0,'','',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',14,'2025-05-05T05:05:05.555555+00:00','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','',0,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','Tên ô 💡 日本語 \'quote\' \"double\" \\ back','missing-parent','missing-parent',14,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back','2025-05-05T05:05:05.555555+00:00','2025-05-05T05:05:05.555555+00:00');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `workspace_settings` (
  `id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `root_path` longtext NOT NULL,
  `default_retention_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `workspace_settings` VALUES
(1,0,'root_path 0',0),
(2,1,'Tên ô 💡 日本語 \'quote\' \"double\" \\ back',NULL),
(3,0,'',14);
